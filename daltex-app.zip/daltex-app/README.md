# DALTEX HQ — IT Asset Management

A fully connected, multi-page React app for IT asset management: login, dashboard,
inventory, employee directory, branches, and an end-to-end hardware checkout
(assignment) flow that generates a delivery contract.

## Getting started

```bash
npm install
npm run dev
```

Then open the URL printed in your terminal (usually `http://localhost:5173`).

To build a production bundle:

```bash
npm run build
npm run preview
```

To lint:

```bash
npm run lint
```

## Project structure

```
src/
  assets/          # Place images/static assets here (empty by default)
  App.css          # Small cross-cutting styles: focus rings, scrollbars, resets
  App.jsx          # The entire app: components, context, pages, and routing
  index.css        # Global reset + font import
  main.jsx         # React entry point
index.html
package.json
eslint.config.js
vite.config.js
```

Everything — UI components, the shared state/context, all seed data, and every
page (Login, Dashboard, Inventory, Employee Directory/Detail, Branches/Branch
Detail, Assignments, the New Assignment wizard, and the Contract Preview) lives
in a single `src/App.jsx`. This mirrors a flat, single-entry-point project layout
rather than splitting into `components/`, `pages/`, `context/`, and `data/`
subfolders.

Inside `App.jsx`, code is organized top-to-bottom in dependency order:

1. Theme constants and seed data
2. Small reusable UI primitives (`Card`, `StatusPill`, `StatCard`, `CategoryIcon`, `Dot`/`Row`/`Field`)
3. Modals (`Modal`, `AddDeviceModal`, `CsvPreviewModal`)
4. Layout chrome (`Sidebar`, `TopBar`)
5. Global state (`AppCtx`, `useApp`, `AppProvider`)
6. Pages, in the order a user would typically reach them (Login → Dashboard →
   Inventory → Employees → Branches → Assignments → New Assignment → Contract)
7. The `Shell` (sidebar + topbar + page router), `Root` (auth gate), and the
   top-level `App` component that's exported as default

## Features

- **Login** — a sign-in screen gates the app. Two demo accounts are listed and
  clickable to autofill. Log out via the user menu in the top-right.
- **Clickable dashboard stats** — Total Assets, Assigned, In Stock, and In
  Maintenance cards navigate to Inventory pre-filtered by that status.
- **Add Device** — opens a form modal; submitted devices are added to inventory
  with status `Unregistered`.
- **Export CSV → real preview** — "Export CSV" (Inventory) and "Export Data"
  (Branches) open a modal rendering the actual export as a table or raw CSV
  text, with a working download button.
- **Branches: working Filter + clickable everything** — filter by health status
  and department; click any row to open a branch detail page; maintenance alert
  cards are clickable shortcuts into their branch.

## How the data flows

All state lives in the `AppProvider` context and is shared across every page:

- **Assigning** an asset (via the New Assignment wizard) moves it from `In Stock`
  to `Assigned`, links it to the employee, adds an entry to the activity log, and
  generates a delivery contract you're routed to.
- **Returning** an asset (from Inventory, Employee Detail, or the Assignments
  page) puts it back into `In Stock` and logs the event.
- **Adding a device** creates a new asset with status `Unregistered` and logs
  the registration event.
- Dashboard, Inventory, and Assignments counts all derive from the same
  `assets` array, so they stay in sync automatically.

## Notes

- Icons are from [lucide-react](https://lucide.dev/).
- No router library is used — navigation is handled by a `page` string in
  context and a simple switch inside `Shell`. Swap in `react-router` if you need
  deep-linkable URLs.
- Login is a front-end-only demo (no real backend/auth). Credentials are listed
  directly on the login screen.
- Dashboard headline stats add fixed offsets on top of the live mock data so
  they match the original design's numbers; the live portion still reacts
  correctly to assign/return/add actions, and clicking through filters the
  *live* portion only.
- `src/App.jsx` is large (~2,900 lines) by design, since this revision
  consolidates what was previously ~17 separate files into one, matching a
  flat single-entry-point project layout.
