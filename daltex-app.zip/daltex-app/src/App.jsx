import React, { useState, useEffect, useRef, createContext, useContext, useMemo } from "react";
import {
  Laptop,
  Monitor,
  Printer,
  Network,
  Mouse,
  Boxes,
  TrendingUp,
  ChevronRight,
  X,
  Download,
  Table2,
  Code,
  Plus,
  Search,
  Bell,
  Settings,
  HelpCircle,
  LogOut,
  ChevronDown,
  Building2,
  Lock,
  Mail,
  Eye,
  EyeOff,
  AlertCircle,
  ClipboardCheck,
  Users,
  Wrench,
  Filter,
  RotateCcw,
  MoreVertical,
  ArrowLeft,
  Key,
  History,
  CheckCircle2,
  AlertTriangle,
  Check,
  ChevronLeft,
  FileText,
  Printer as PrinterIcon,
  LayoutGrid,
} from "lucide-react";
import "./App.css";

/* ===== from theme.js ===== */
const NAVY = "#0f1a35";
const ORANGE = "#d97706";

/* ===== from data/seedData.js ===== */
const initialEmployees = [
  { id: "88201", name: "Marcus Thorne", role: "Senior Product Manager", dept: "Product", location: "London, UK", status: "On Leave", email: "marcus.thorne@daltexhq.com", tenure: "2.1 Years", avatarColor: "#6b7280" },
  { id: "88402", name: "Sarah Jenkins", role: "Director of People Ops", dept: "People Operations", location: "London, UK (HQ)", status: "Active", email: "s.jenkins@daltexhq.com", tenure: "3.4 Years", avatarColor: "#d97706" },
  { id: "88105", name: "Elena Rodriguez", role: "Lead Frontend Engineer", dept: "Engineering", location: "Madrid, ES", status: "Active", email: "elena.rodriguez@daltexhq.com", tenure: "1.8 Years", avatarColor: "#0f172a" },
  { id: "88310", name: "Chen Wei", role: "Cybersecurity Analyst", dept: "IT", location: "Singapore, SG", status: "Active", email: "chen.wei@daltexhq.com", tenure: "0.9 Years", avatarColor: "#0f172a" },
  { id: "88511", name: "Jonathan Wu", role: "Chief Financial Officer", dept: "Finance", location: "San Francisco, US", status: "Active", email: "jonathan.wu@daltexhq.com", tenure: "5.2 Years", avatarColor: "#0f172a" },
  { id: "88612", name: "Amina Diallo", role: "Senior UX Designer", dept: "Design", location: "Paris, FR", status: "Offboarded", email: "amina.diallo@daltexhq.com", tenure: "2.6 Years", avatarColor: "#9ca3af" },
  { id: "88713", name: "Robert Grant", role: "General Counsel", dept: "Legal", location: "Toronto, CA", status: "Active", email: "robert.grant@daltexhq.com", tenure: "4.0 Years", avatarColor: "#0f172a" },
  { id: "88820", name: "Liam O'Connell", role: "Marketing Specialist", dept: "Marketing", location: "Dublin, IE", status: "Active", email: "liam.oconnell@daltexhq.com", tenure: "1.1 Years", avatarColor: "#0f172a" },
];

const initialAssets = [
  { id: "AST-99021", brand: "Apple", model: 'MacBook Pro 14" M3', serial: "XG8829-91", status: "Assigned", assignedTo: "88105", branch: "London HQ", category: "Laptops & PCs", condition: "Excellent" },
  { id: "AST-88210", brand: "Dell", model: "XPS 15 (9530)", serial: "JX-112-QW", status: "In Stock", assignedTo: null, branch: "New York Hub", category: "Laptops & PCs", condition: "Brand New" },
  { id: "AST-44109", brand: "Lenovo", model: "ThinkPad X1 Carbon", serial: "LNV-881-TP", status: "Repair", assignedTo: null, branch: "Berlin Office", category: "Laptops & PCs", condition: "Pending Fix" },
  { id: "AST-11002", brand: "Apple", model: 'iMac 21.5" (2017)', serial: "AP-OLD-99", status: "Retired", assignedTo: null, branch: "London HQ", category: "Laptops & PCs", condition: "Retired" },
  { id: "AST-99443", brand: "Dell", model: "Precision 3581", serial: "DL-PRC-44", status: "Assigned", assignedTo: "88310", branch: "Singapore R&D", category: "Laptops & PCs", condition: "Excellent" },
  { id: "AST-14001", brand: "Apple", model: 'MacBook Pro 14"', serial: "C02XL01P0G9", status: "Assigned", assignedTo: "88402", branch: "London HQ", category: "Laptops & PCs", condition: "Premium" },
  { id: "AST-77302", brand: "Dell", model: '32" UltraSharp', serial: "DELL-882-X90", status: "Assigned", assignedTo: "88402", branch: "London HQ", category: "Monitors", condition: "Standard" },
  { id: "AST-50012", brand: "Cisco", model: "Router X-200", serial: "CS-RX2-0012", status: "In Stock", assignedTo: null, branch: "Khatatba Branch", category: "Networking", condition: "Excellent" },
  { id: "AST-60019", brand: "Apple", model: "iPad Air Gen 5", serial: "IPD-AIR5-09", status: "Repair", assignedTo: null, branch: "Sadat City Farm", category: "Mobile Devices", condition: "Screen Repair" },
];

const initialBranches = [
  { id: "HQ", name: "Daltex Headquarters", region: "Cairo - Central District", departments: ["IT", "HR", "OPS"], assets: 1240, health: "good" },
  { id: "WN", name: "Wadi El Natrun", region: "Agricultural Hub", departments: ["LOG", "OPS"], assets: 854, health: "good" },
  { id: "SD", name: "Sadat City", region: "Production Plant", departments: ["IT", "LOG"], assets: 612, health: "warning" },
  { id: "AP", name: "Alexandria Port", region: "Logistics Center", departments: ["LOG", "HR"], assets: 433, health: "good" },
  { id: "SM", name: "Samalout", region: "Upper Egypt Hub", departments: ["LOG"], assets: 218, health: "good" },
  { id: "SH", name: "Sharqia", region: "Storage Facility", departments: ["OPS"], assets: 305, health: "good" },
];

const initialActivity = [
  { id: 1, title: 'MacBook Pro 14"', desc: "Assigned to Ahmed Mansour", sub: "Sadat City Hub", time: "2m ago", type: "assign" },
  { id: 2, title: "Cisco Router X-200", desc: "Returned to stock from Khatatba Branch", sub: "Condition: Excellent", time: "45m ago", type: "return" },
  { id: 3, title: "iPad Air Gen 5", desc: "Moved to Repair Queue", sub: "Ticket #DX-9902: Screen replacement", time: "2h ago", type: "repair" },
  { id: 4, title: "Bulk Audit: Zone B", desc: "Audit completed by S. Khalil", sub: "42 assets verified, 0 discrepancies", time: "5h ago", type: "audit" },
];

/* ===== from components/Card.jsx ===== */
function Card({ children, style, onClick, onMouseEnter, onMouseLeave }) {
  return (
    <div
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      style={{
        background: "#fff",
        borderRadius: 12,
        border: "1px solid #eef0f3",
        padding: 22,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

/* ===== shared BackButton ===== */
function BackButton({ onClick, label = "Back" }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        border: "none",
        background: "none",
        color: ORANGE,
        fontWeight: 700,
        fontSize: 13.5,
        cursor: "pointer",
        marginBottom: 18,
        padding: 0,
      }}
    >
      <ArrowLeft size={15} /> {label}
    </button>
  );
}

/* ===== from components/CategoryIcon.jsx ===== */
function CategoryIcon({ category, size = 16 }) {
  const props = { size, strokeWidth: 1.8 };
  switch (category) {
    case "Laptops & PCs":
      return <Laptop {...props} />;
    case "Monitors":
      return <Monitor {...props} />;
    case "Printers":
      return <Printer {...props} />;
    case "Networking":
      return <Network {...props} />;
    case "Peripherals":
      return <Mouse {...props} />;
    default:
      return <Boxes {...props} />;
  }
}

/* ===== from components/Misc.jsx ===== */
function Dot({ color }) {
  return (
    <span
      style={{
        width: 8,
        height: 8,
        borderRadius: 99,
        background: color,
        display: "inline-block",
      }}
    />
  );
}

function Row({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
      <span style={{ color: "#94a3b8" }}>{label}</span>
      <span style={{ color: "#0f172a", fontWeight: 600 }}>{value}</span>
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: "#94a3b8", fontWeight: 700, marginBottom: 6 }}>{label}</div>
      <div
        style={{
          border: "1px solid #eef0f3",
          borderRadius: 7,
          padding: "9px 12px",
          fontSize: 13.5,
          color: "#0f172a",
          background: "#f8fafc",
        }}
      >
        {value}
      </div>
    </div>
  );
}

/* ===== from components/StatusPill.jsx ===== */
const STATUS_MAP = {
  Assigned: { bg: "#dcfce7", color: "#15803d", label: "ASSIGNED" },
  "In Stock": { bg: "#f1f5f9", color: "#475569", label: "IN STOCK" },
  Repair: { bg: "#fee2e2", color: "#dc2626", label: "REPAIR" },
  Retired: { bg: "#fee2e2", color: "#dc2626", label: "RETIRED" },
  Unregistered: { bg: "#fef3c7", color: "#b45309", label: "UNREGISTERED" },
  Active: { bg: "#dcfce7", color: "#15803d", label: "ACTIVE" },
  "On Leave": { bg: "#fef3c7", color: "#b45309", label: "ON LEAVE" },
  Offboarded: { bg: "#fee2e2", color: "#dc2626", label: "OFFBOARDED" },
};

function StatusPill({ status }) {
  const s = STATUS_MAP[status] || STATUS_MAP["In Stock"];
  return (
    <span
      style={{
        background: s.bg,
        color: s.color,
        fontSize: 11,
        fontWeight: 700,
        padding: "3px 9px",
        borderRadius: 999,
        letterSpacing: 0.3,
        whiteSpace: "nowrap",
      }}
    >
      {s.label}
    </span>
  );
}

/* ===== from components/StatCard.jsx ===== */
function StatCard({ icon, iconBg, label, value, badge, sub, danger, onClick }) {
  const [hover, setHover] = useState(false);
  const clickable = typeof onClick === "function";

  return (
    <Card
      onMouseEnter={() => clickable && setHover(true)}
      onMouseLeave={() => clickable && setHover(false)}
      onClick={onClick}
      style={{
        flex: 1,
        minWidth: 0,
        cursor: clickable ? "pointer" : "default",
        transition: "box-shadow .15s, transform .15s, border-color .15s",
        boxShadow: clickable && hover ? "0 8px 20px rgba(15,23,42,0.08)" : "none",
        transform: clickable && hover ? "translateY(-2px)" : "none",
        borderColor: clickable && hover ? "#d1d5db" : "#eef0f3",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div
          style={{
            width: 38,
            height: 38,
            borderRadius: 9,
            background: iconBg,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {icon}
        </div>
        {badge && (
          <span style={{ color: "#16a34a", fontSize: 12.5, fontWeight: 700, display: "flex", alignItems: "center", gap: 3 }}>
            <TrendingUp size={13} />
            {badge}
          </span>
        )}
        {!badge && clickable && (
          <ChevronRight size={15} color={hover ? "#475569" : "#cbd5e1"} style={{ transition: "color .15s" }} />
        )}
      </div>
      <div style={{ fontSize: 11.5, color: "#94a3b8", fontWeight: 700, letterSpacing: 0.4, marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 800, color: danger ? "#dc2626" : "#0f172a" }}>{value}</div>
      {sub && <div style={{ marginTop: 8 }}>{sub}</div>}
    </Card>
  );
}

/* ===== from components/Modal.jsx ===== */
function Modal({ title, subtitle, onClose, children, width = 560, footer }) {
  useEffect(() => {
    function handleKey(e) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onClose]);

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.45)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 100,
        padding: 20,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#fff",
          borderRadius: 14,
          width,
          maxWidth: "100%",
          maxHeight: "88vh",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 24px 64px rgba(15,23,42,0.25)",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "20px 24px", borderBottom: "1px solid #eef0f3" }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: 17, color: "#0f172a" }}>{title}</div>
            {subtitle && <div style={{ fontSize: 12.5, color: "#94a3b8", marginTop: 3 }}>{subtitle}</div>}
          </div>
          <button onClick={onClose} style={{ border: "none", background: "#f1f5f9", borderRadius: 8, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#475569", flexShrink: 0 }}>
            <X size={16} />
          </button>
        </div>
        <div style={{ padding: 24, overflowY: "auto", flex: 1 }}>{children}</div>
        {footer && <div style={{ padding: "16px 24px", borderTop: "1px solid #eef0f3" }}>{footer}</div>}
      </div>
    </div>
  );
}

/* ===== from components/AddDeviceModal.jsx ===== */
const CATEGORIES = ["Laptops & PCs", "Monitors", "Printers", "Networking", "Peripherals"];
const BRANCHES = ["London HQ", "New York Hub", "Berlin Office", "Singapore R&D", "Khatatba Branch", "Sadat City Farm"];

function FormField({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 7 }}>{label}</div>
      {children}
    </div>
  );
}

const inputStyle = {
  width: "100%",
  border: "1px solid #eef0f3",
  borderRadius: 8,
  padding: "10px 12px",
  fontSize: 13.5,
  outline: "none",
  boxSizing: "border-box",
};

function AddDeviceModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({
    category: CATEGORIES[0],
    brand: "",
    model: "",
    serial: "",
    branch: BRANCHES[0],
  });
  const [error, setError] = useState("");

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function handleSubmit() {
    if (!form.brand.trim() || !form.model.trim() || !form.serial.trim()) {
      setError("Brand, model, and serial number are required.");
      return;
    }
    onSubmit(form);
  }

  return (
    <Modal
      title="Add New Device"
      subtitle="Register a new device into inventory. It will be unregistered until assigned or verified."
      onClose={onClose}
      footer={
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
          <button
            onClick={onClose}
            style={{ border: "1px solid #eef0f3", background: "#fff", color: "#475569", fontWeight: 700, fontSize: 13, padding: "10px 18px", borderRadius: 8, cursor: "pointer" }}
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            style={{ border: "none", background: ORANGE, color: "#fff", fontWeight: 700, fontSize: 13, padding: "10px 20px", borderRadius: 8, cursor: "pointer" }}
          >
            Add Device
          </button>
        </div>
      }
    >
      {error && (
        <div style={{ background: "#fee2e2", color: "#dc2626", fontSize: 12.5, padding: "10px 12px", borderRadius: 8, marginBottom: 16 }}>{error}</div>
      )}

      <FormField label="Category">
        <select value={form.category} onChange={(e) => update("category", e.target.value)} style={inputStyle}>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </FormField>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <FormField label="Brand">
          <input value={form.brand} onChange={(e) => update("brand", e.target.value)} placeholder="e.g. Dell, Apple, Cisco" style={inputStyle} />
        </FormField>
        <FormField label="Model">
          <input value={form.model} onChange={(e) => update("model", e.target.value)} placeholder='e.g. XPS 15 (9530)' style={inputStyle} />
        </FormField>
      </div>

      <FormField label="Serial Number">
        <input value={form.serial} onChange={(e) => update("serial", e.target.value)} placeholder="e.g. SN-882-X90" style={inputStyle} />
      </FormField>

      <FormField label="Branch / Location">
        <select value={form.branch} onChange={(e) => update("branch", e.target.value)} style={inputStyle}>
          {BRANCHES.map((b) => (
            <option key={b} value={b}>{b}</option>
          ))}
        </select>
      </FormField>

      <div style={{ background: "#fef3e2", borderRadius: 8, padding: "10px 14px", fontSize: 12.5, color: "#b45309" }}>
        New devices are added with status <strong>Unregistered</strong> until they&apos;re checked in or assigned.
      </div>
    </Modal>
  );
}

/* ===== from components/CsvPreviewModal.jsx ===== */
function toCsv(rows, headers) {
  const escape = (val) => {
    const s = String(val ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [headers.map(escape).join(",")];
  rows.forEach((r) => lines.push(headers.map((h) => escape(r[h])).join(",")));
  return lines.join("\n");
}

function escapeHtml(val) {
  return String(val ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function buildPrintableHtml(title, headers, rows) {
  const headHtml = headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("");
  const rowsHtml = rows
    .map((r) => `<tr>${headers.map((h) => `<td>${escapeHtml(r[h])}</td>`).join("")}</tr>`)
    .join("");
  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${escapeHtml(title)}</title>
        <style>
          * { box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; padding: 24px; color: #0f172a; }
          h1 { font-size: 16px; margin: 0 0 4px; }
          .meta { font-size: 11px; color: #64748b; margin-bottom: 16px; }
          table { width: 100%; border-collapse: collapse; font-size: 11px; }
          th, td { border: 1px solid #e2e8f0; padding: 6px 8px; text-align: left; white-space: nowrap; }
          th { background: #f8fafc; font-weight: 700; color: #475569; }
          tr:nth-child(even) td { background: #fafbfc; }
        </style>
      </head>
      <body>
        <h1>DALTEX HQ — ${escapeHtml(title)}</h1>
        <div class="meta">${rows.length} row${rows.length === 1 ? "" : "s"} · exported ${new Date().toLocaleString()}</div>
        <table>
          <thead><tr>${headHtml}</tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </body>
    </html>
  `;
}

function downloadAsPdf(title, headers, rows) {
  const html = buildPrintableHtml(title, headers, rows);
  const iframe = document.createElement("iframe");
  iframe.style.position = "fixed";
  iframe.style.right = "0";
  iframe.style.bottom = "0";
  iframe.style.width = "0";
  iframe.style.height = "0";
  iframe.style.border = "0";
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow.document;
  doc.open();
  doc.write(html);
  doc.close();

  iframe.contentWindow.focus();
  // Give the iframe a brief moment to lay out the content before invoking print,
  // which on most browsers offers "Save as PDF" as a destination.
  setTimeout(() => {
    iframe.contentWindow.print();
    setTimeout(() => document.body.removeChild(iframe), 1000);
  }, 250);
}

function CsvPreviewModal({ onClose, rows, headers, filename, title = "Export Preview" }) {
  const [view, setView] = useState("table");
  const csvText = toCsv(rows, headers);
  const pdfTitle = filename.replace(/\.csv$/i, "").replace(/_/g, " ");

  function handleDownloadCsv() {
    const blob = new Blob([csvText], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  function handleDownloadPdf() {
    downloadAsPdf(pdfTitle, headers, rows);
  }

  return (
    <Modal
      title={title}
      subtitle={`${filename} · ${rows.length} row${rows.length === 1 ? "" : "s"}`}
      onClose={onClose}
      width={760}
      footer={
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", gap: 6 }}>
            <button
              onClick={() => setView("table")}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                border: "1px solid #eef0f3", borderRadius: 7, padding: "7px 12px",
                fontSize: 12.5, fontWeight: 700, cursor: "pointer",
                background: view === "table" ? "#f1f5f9" : "#fff",
                color: view === "table" ? "#0f172a" : "#94a3b8",
              }}
            >
              <Table2 size={13} /> Table
            </button>
            <button
              onClick={() => setView("raw")}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                border: "1px solid #eef0f3", borderRadius: 7, padding: "7px 12px",
                fontSize: 12.5, fontWeight: 700, cursor: "pointer",
                background: view === "raw" ? "#f1f5f9" : "#fff",
                color: view === "raw" ? "#0f172a" : "#94a3b8",
              }}
            >
              <Code size={13} /> Raw CSV
            </button>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={handleDownloadPdf}
              style={{ display: "flex", alignItems: "center", gap: 7, border: "1px solid #eef0f3", background: "#fff", color: "#475569", fontWeight: 700, fontSize: 13, padding: "10px 16px", borderRadius: 8, cursor: "pointer" }}
            >
              <FileText size={14} /> Save as PDF
            </button>
            <button
              onClick={handleDownloadCsv}
              style={{ display: "flex", alignItems: "center", gap: 7, border: "none", background: ORANGE, color: "#fff", fontWeight: 700, fontSize: 13, padding: "10px 18px", borderRadius: 8, cursor: "pointer" }}
            >
              <Download size={14} /> Download CSV
            </button>
          </div>
        </div>
      }
    >
      {view === "table" ? (
        <div style={{ overflowX: "auto", border: "1px solid #eef0f3", borderRadius: 8 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#f8fafc" }}>
                {headers.map((h) => (
                  <th key={h} style={{ padding: "9px 14px", textAlign: "left", color: "#94a3b8", fontWeight: 700, fontSize: 11, borderBottom: "1px solid #eef0f3", whiteSpace: "nowrap" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} style={{ borderBottom: "1px solid #f3f4f6" }}>
                  {headers.map((h) => (
                    <td key={h} style={{ padding: "9px 14px", color: "#0f172a", whiteSpace: "nowrap" }}>
                      {String(r[h] ?? "")}
                    </td>
                  ))}
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={headers.length} style={{ padding: 24, textAlign: "center", color: "#94a3b8" }}>
                    No rows to export.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <pre
          style={{
            background: "#0f172a",
            color: "#e2e8f0",
            borderRadius: 8,
            padding: 16,
            fontSize: 12,
            lineHeight: 1.6,
            overflowX: "auto",
            margin: 0,
            fontFamily: "'SF Mono', Menlo, Consolas, monospace",
          }}
        >
          {csvText}
        </pre>
      )}
    </Modal>
  );
}

/* ===== from components/Sidebar.jsx ===== */
function Sidebar({ items, activePage, onNavigate, onAddNewAsset, brand, sub }) {
  return (
    <div
      style={{
        width: 230,
        background: NAVY,
        color: "#fff",
        display: "flex",
        flexDirection: "column",
        padding: "24px 16px",
        flexShrink: 0,
      }}
    >
      <div style={{ padding: "0 8px 28px" }}>
        <div style={{ fontWeight: 800, fontSize: 18, letterSpacing: 0.3 }}>{brand}</div>
        <div style={{ fontSize: 11.5, color: "#94a3b8", marginTop: 2 }}>{sub}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 2, flex: 1 }}>
        {items.map((item) => {
          const active = item.key === activePage;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 11,
                padding: "10px 12px",
                borderRadius: 8,
                border: "none",
                cursor: "pointer",
                textAlign: "left",
                background: active ? ORANGE : "transparent",
                color: active ? "#fff" : "#cbd5e1",
                fontSize: 14,
                fontWeight: active ? 600 : 500,
                transition: "background .15s",
              }}
            >
              {item.icon}
              {item.label}
            </button>
          );
        })}
      </div>
      <button
        onClick={() => (onAddNewAsset ? onAddNewAsset() : onNavigate("newAssignment"))}
        style={{
          marginTop: 12,
          background: ORANGE,
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "12px 14px",
          fontWeight: 700,
          fontSize: 13.5,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
          cursor: "pointer",
        }}
      >
        <Plus size={16} /> Add New Asset
      </button>
    </div>
  );
}

/* ===== from components/TopBar.jsx ===== */
function TopBar({ placeholder, userName, userRole, avatarColor, alert, onLogout, searchValue, onSearchChange, onSearchFocus }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "18px 28px",
        background: "#fff",
        borderBottom: "1px solid #eef0f3",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          background: "#f8fafc",
          border: "1px solid #eef0f3",
          borderRadius: 8,
          padding: "9px 14px",
          width: 360,
        }}
      >
        <Search size={16} color="#94a3b8" />
        <input
          value={searchValue ?? ""}
          onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
          onFocus={() => onSearchFocus && onSearchFocus()}
          placeholder={placeholder}
          style={{ border: "none", outline: "none", background: "none", fontSize: 13.5, width: "100%", color: "#0f172a" }}
        />
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
        <div style={{ position: "relative" }}>
          <Bell size={18} color="#475569" />
          {alert && (
            <span
              style={{
                position: "absolute",
                top: -2,
                right: -2,
                width: 7,
                height: 7,
                borderRadius: 99,
                background: "#ef4444",
              }}
            />
          )}
        </div>
        <Settings size={18} color="#475569" />
        <HelpCircle size={18} color="#475569" />
        <div style={{ width: 1, height: 26, background: "#eef0f3" }} />
        <div style={{ position: "relative" }} ref={menuRef}>
          <button
            onClick={() => setMenuOpen((o) => !o)}
            style={{ display: "flex", alignItems: "center", gap: 9, border: "none", background: "none", cursor: "pointer", padding: 0 }}
          >
            <div
              style={{
                width: 34,
                height: 34,
                borderRadius: "50%",
                background: avatarColor || "#0f172a",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                fontSize: 13,
                fontWeight: 700,
                flexShrink: 0,
              }}
            >
              {userName.split(" ").map((p) => p[0]).join("").slice(0, 2)}
            </div>
            <div style={{ textAlign: "left" }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{userName}</div>
              <div style={{ fontSize: 11.5, color: "#d97706", fontWeight: 600 }}>{userRole}</div>
            </div>
            <ChevronDown size={14} color="#94a3b8" />
          </button>

          {menuOpen && (
            <div
              style={{
                position: "absolute",
                top: "calc(100% + 10px)",
                right: 0,
                background: "#fff",
                border: "1px solid #eef0f3",
                borderRadius: 10,
                boxShadow: "0 12px 32px rgba(15,23,42,0.12)",
                width: 180,
                overflow: "hidden",
                zIndex: 50,
              }}
            >
              <button
                onClick={() => {
                  setMenuOpen(false);
                  onLogout && onLogout();
                }}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: 9,
                  padding: "11px 14px",
                  border: "none",
                  background: "none",
                  cursor: "pointer",
                  fontSize: 13,
                  fontWeight: 600,
                  color: "#dc2626",
                  textAlign: "left",
                }}
              >
                <LogOut size={15} /> Log Out
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ===== from context/AppContext.jsx ===== */
const AppCtx = createContext(null);

function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

function AppProvider({ children }) {
  const [assets, setAssets] = useState(initialAssets);
  const [employees] = useState(initialEmployees);
  const [branches] = useState(initialBranches);
  const [activity, setActivity] = useState(initialActivity);
  const [page, setPage] = useState("dashboard");
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [lastContract, setLastContract] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [inventoryStatusFilter, setInventoryStatusFilter] = useState(null);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [showAddDeviceModal, setShowAddDeviceModal] = useState(false);
  const [globalSearchQuery, setGlobalSearchQuery] = useState("");
  const [employeeSearchQuery, setEmployeeSearchQuery] = useState("");
  const [employeeSort, setEmployeeSort] = useState("name-asc");

  function login(user) {
    setCurrentUser(user);
    setIsAuthenticated(true);
    setPage("dashboard");
  }

  function logout() {
    setIsAuthenticated(false);
    setCurrentUser(null);
  }

  function goToInventory(statusFilter = null) {
    setInventoryStatusFilter(statusFilter);
    setPage("inventory");
  }

  function addAsset(newAsset) {
    const id = `AST-${Math.floor(10000 + Math.random() * 89999)}`;
    const asset = {
      id,
      status: "Unregistered",
      assignedTo: null,
      condition: "Brand New",
      ...newAsset,
    };
    setAssets((prev) => [asset, ...prev]);
    setActivity((prev) => [
      {
        id: Date.now(),
        title: `${asset.brand} ${asset.model}`,
        desc: "Registered as new device",
        sub: asset.branch,
        time: "Just now",
        type: "register",
      },
      ...prev,
    ]);
    return asset;
  }

  function assignAsset(assetId, recipient) {
    // recipient is either { type: "employee", employeeId } or { type: "branch", branchId, departmentName }
    const asset = assets.find((a) => a.id === assetId);
    if (!asset || !recipient) return null;

    if (recipient.type === "branch") {
      const branch = branches.find((b) => b.id === recipient.branchId);
      if (!branch) return null;

      setAssets((prev) =>
        prev.map((a) =>
          a.id === assetId
            ? { ...a, status: "Assigned", assignedTo: null, assignedBranch: branch.id, branch: branch.name }
            : a
        )
      );

      setActivity((prev) => [
        {
          id: Date.now(),
          title: asset.model,
          desc: `Assigned to ${branch.name}${recipient.departmentName ? ` (${recipient.departmentName})` : ""}`,
          sub: branch.region,
          time: "Just now",
          type: "assign",
        },
        ...prev,
      ]);

      const contract = {
        docId: `DX-2024-${Math.floor(Math.random() * 9000 + 1000)}`,
        date: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
        branchRecipient: { branch, departmentName: recipient.departmentName || null },
        asset,
        officer: "Alex Mercer",
      };
      setLastContract(contract);
      return contract;
    }

    // Default: employee recipient
    const employeeId = recipient.type === "employee" ? recipient.employeeId : recipient;
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return null;

    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, status: "Assigned", assignedTo: employeeId } : a))
    );

    setActivity((prev) => [
      {
        id: Date.now(),
        title: asset.model,
        desc: `Assigned to ${emp.name}`,
        sub: emp.location,
        time: "Just now",
        type: "assign",
      },
      ...prev,
    ]);

    const contract = {
      docId: `DX-2024-${Math.floor(Math.random() * 9000 + 1000)}`,
      date: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
      employee: emp,
      asset,
      officer: "Alex Mercer",
    };
    setLastContract(contract);
    return contract;
  }

  function returnAsset(assetId) {
    const asset = assets.find((a) => a.id === assetId);
    if (!asset) return;

    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, status: "In Stock", assignedTo: null } : a))
    );

    setActivity((prev) => [
      {
        id: Date.now(),
        title: asset.model,
        desc: `Returned to stock from ${asset.branch}`,
        sub: `Condition: ${asset.condition}`,
        time: "Just now",
        type: "return",
      },
      ...prev,
    ]);
  }

  const stats = useMemo(() => {
    const total = assets.length;
    const assigned = assets.filter((a) => a.status === "Assigned").length;
    const inStock = assets.filter((a) => a.status === "In Stock").length;
    const maintenance = assets.filter((a) => a.status === "Repair").length;
    return { total, assigned, inStock, maintenance };
  }, [assets]);

  const value = {
    assets,
    employees,
    branches,
    activity,
    stats,
    page,
    setPage,
    selectedEmployeeId,
    setSelectedEmployeeId,
    assignAsset,
    returnAsset,
    addAsset,
    lastContract,
    setLastContract,
    isAuthenticated,
    currentUser,
    login,
    logout,
    inventoryStatusFilter,
    setInventoryStatusFilter,
    goToInventory,
    selectedBranchId,
    setSelectedBranchId,
    showAddDeviceModal,
    setShowAddDeviceModal,
    globalSearchQuery,
    setGlobalSearchQuery,
    employeeSearchQuery,
    setEmployeeSearchQuery,
    employeeSort,
    setEmployeeSort,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

/* ===== from pages/Login.jsx ===== */
const DEMO_ACCOUNTS = [
  { email: "alex.mercer@daltexhq.com", password: "daltex2024", name: "Alex Mercer", role: "Systems Admin", avatar: "#475569" },
  { email: "admin@daltexhq.com", password: "admin123", name: "Admin User", role: "Global Admin", avatar: "#0f172a" },
];

function Login() {
  const { login } = useApp();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    const match = DEMO_ACCOUNTS.find(
      (acc) => acc.email.toLowerCase() === email.trim().toLowerCase() && acc.password === password
    );
    if (!match) {
      setError("Incorrect email or password. Try the demo credentials below.");
      return;
    }
    setError("");
    login(match);
  }

  function fillDemo(acc) {
    setEmail(acc.email);
    setPassword(acc.password);
    setError("");
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f4f5f7",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      }}
    >
      <div style={{ display: "flex", width: 880, maxWidth: "92vw", borderRadius: 16, overflow: "hidden", boxShadow: "0 20px 60px rgba(15,23,42,0.12)" }}>
        {/* Left brand panel */}
        <div
          style={{
            flex: 1,
            background: NAVY,
            padding: 44,
            color: "#fff",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 9, background: ORANGE, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Building2 size={20} color="#fff" />
            </div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 17 }}>DALTEX HQ</div>
              <div style={{ fontSize: 11.5, color: "#94a3b8" }}>IT Asset Management</div>
            </div>
          </div>

          <div>
            <div style={{ fontSize: 24, fontWeight: 800, lineHeight: 1.35, marginBottom: 14 }}>
              Every laptop, router, and badge — tracked in one place.
            </div>
            <div style={{ fontSize: 13.5, color: "#94a3b8", lineHeight: 1.6 }}>
              Sign in to manage inventory, assignments, and branch operations across all 21 regional hubs.
            </div>
          </div>

          <div style={{ fontSize: 11.5, color: "#64748b" }}>© 2024 Daltex HQ. All rights reserved.</div>
        </div>

        {/* Right form panel */}
        <div style={{ flex: 1, background: "#fff", padding: 44, display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a", marginBottom: 6 }}>Welcome back</div>
          <div style={{ fontSize: 13.5, color: "#94a3b8", marginBottom: 28 }}>Sign in to your Asset Central account.</div>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 7 }}>Email Address</div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, border: "1px solid #eef0f3", borderRadius: 8, padding: "11px 14px" }}>
                <Mail size={15} color="#94a3b8" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@daltexhq.com"
                  required
                  style={{ border: "none", outline: "none", fontSize: 13.5, width: "100%" }}
                />
              </div>
            </div>

            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 7 }}>Password</div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, border: "1px solid #eef0f3", borderRadius: 8, padding: "11px 14px" }}>
                <Lock size={15} color="#94a3b8" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  style={{ border: "none", outline: "none", fontSize: 13.5, width: "100%" }}
                />
                <button type="button" onClick={() => setShowPassword((s) => !s)} style={{ border: "none", background: "none", cursor: "pointer", color: "#94a3b8", display: "flex" }}>
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div style={{ display: "flex", alignItems: "flex-start", gap: 8, background: "#fee2e2", color: "#dc2626", fontSize: 12.5, padding: "10px 12px", borderRadius: 8, marginBottom: 14 }}>
                <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 1 }} />
                <span>{error}</span>
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 20, marginTop: error ? 0 : 14 }}>
              <button type="button" style={{ border: "none", background: "none", color: ORANGE, fontWeight: 700, fontSize: 12.5, cursor: "pointer" }}>
                Forgot password?
              </button>
            </div>

            <button
              type="submit"
              style={{
                width: "100%",
                background: ORANGE,
                color: "#fff",
                border: "none",
                borderRadius: 8,
                padding: "13px",
                fontWeight: 700,
                fontSize: 14,
                cursor: "pointer",
              }}
            >
              Sign In
            </button>
          </form>

          <div style={{ marginTop: 26, borderTop: "1px solid #eef0f3", paddingTop: 18 }}>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: "#94a3b8", marginBottom: 10, letterSpacing: 0.3 }}>DEMO CREDENTIALS</div>
            {DEMO_ACCOUNTS.map((acc) => (
              <button
                key={acc.email}
                onClick={() => fillDemo(acc)}
                type="button"
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  border: "1px solid #eef0f3",
                  borderRadius: 8,
                  padding: "9px 12px",
                  marginBottom: 8,
                  background: "#f8fafc",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <div>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: "#0f172a" }}>{acc.name}</div>
                  <div style={{ fontSize: 11.5, color: "#94a3b8" }}>{acc.email}</div>
                </div>
                <span style={{ fontSize: 11, color: ORANGE, fontWeight: 700 }}>Use</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ===== from pages/Dashboard.jsx ===== */
function Dashboard() {
  const { stats, branches, activity, setPage, goToInventory } = useApp();

  const branchDist = [
    { name: "Sadat City Farm", value: 542, pct: 43, color: NAVY },
    { name: "Khatatba Branch", value: 318, pct: 25, color: ORANGE },
    { name: "Headquarters (Cairo)", value: 290, pct: 23, color: NAVY },
    { name: "Logistics & Sorting", value: 122, pct: 9, color: "#cbd5e1" },
  ];

  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", gap: 16 }}>
        <StatCard
          icon={<ClipboardCheck size={18} color={NAVY} />}
          iconBg="#e2e8f0"
          label="TOTAL ASSETS"
          value={stats.total + 1263}
          badge="+2.4%"
          onClick={() => goToInventory(null)}
        />
        <StatCard
          icon={<Users size={18} color="#475569" />}
          iconBg="#e2e8f0"
          label="ASSIGNED"
          value={stats.assigned + 1093}
          onClick={() => goToInventory("Assigned")}
          sub={
            <div style={{ height: 6, borderRadius: 99, background: "#eef0f3", overflow: "hidden" }}>
              <div style={{ width: "86%", height: "100%", background: ORANGE }} />
            </div>
          }
        />
        <StatCard
          icon={<Building2 size={18} color="#475569" />}
          iconBg="#e2e8f0"
          label="IN STOCK"
          value={stats.inStock + 161}
          onClick={() => goToInventory("In Stock")}
          sub={<div style={{ fontSize: 12, color: "#94a3b8" }}>Available for deployment</div>}
        />
        <StatCard
          icon={<Wrench size={18} color="#dc2626" />}
          iconBg="#fee2e2"
          label="IN MAINTENANCE"
          value={stats.maintenance + 12}
          danger
          onClick={() => goToInventory("Repair")}
          sub={
            <div style={{ display: "flex", gap: 6 }}>
              <span style={{ background: "#fee2e2", color: "#dc2626", fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 999 }}>8 Critical</span>
              <span style={{ background: "#f1f5f9", color: "#475569", fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 999 }}>6 Pending</span>
            </div>
          }
        />
      </div>

      <div style={{ display: "flex", gap: 20 }}>
        <Card style={{ flex: 2 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
            <div>
              <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a" }}>Branch Distribution</div>
              <div style={{ fontSize: 12.5, color: "#94a3b8", marginTop: 2 }}>Asset allocation across primary operational hubs</div>
            </div>
            <button
              onClick={() => setPage("branches")}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                border: "1px solid #eef0f3",
                borderRadius: 7,
                padding: "7px 12px",
                fontSize: 12.5,
                fontWeight: 600,
                color: "#475569",
                background: "#fff",
                cursor: "pointer",
              }}
            >
              <Filter size={13} /> Filter
            </button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            {branchDist.map((b) => (
              <div key={b.name}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6 }}>
                  <span style={{ fontWeight: 700, color: "#0f172a" }}>{b.name}</span>
                  <span style={{ color: "#64748b" }}>
                    {b.value} Assets ({b.pct}%)
                  </span>
                </div>
                <div style={{ height: 8, borderRadius: 99, background: "#eef0f3", overflow: "hidden" }}>
                  <div style={{ width: `${b.pct}%`, height: "100%", background: b.color }} />
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 18, marginTop: 22, fontSize: 12, color: "#64748b" }}>
            <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <Dot color={NAVY} />
              Laptops
            </span>
            <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <Dot color={ORANGE} />
              Networking
            </span>
            <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <Dot color="#0f172a" />
              Mobile Devices
            </span>
          </div>
        </Card>

        <Card style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a" }}>Recent Activity</div>
          <div style={{ fontSize: 12.5, color: "#94a3b8", marginTop: 2, marginBottom: 16 }}>Live assignment logs</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {activity.slice(0, 4).map((a) => (
              <div key={a.id} style={{ display: "flex", gap: 12 }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    flexShrink: 0,
                    background:
                      a.type === "assign" ? "#fef3e2" : a.type === "return" ? "#dcfce7" : a.type === "repair" ? "#fee2e2" : "#e2e8f0",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {a.type === "assign" && <Laptop size={15} color={ORANGE} />}
                  {a.type === "return" && <RotateCcw size={15} color="#16a34a" />}
                  {a.type === "repair" && <Wrench size={15} color="#dc2626" />}
                  {a.type === "audit" && <ClipboardCheck size={15} color="#475569" />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ fontWeight: 700, fontSize: 13, color: "#0f172a" }}>{a.title}</span>
                    <span style={{ fontSize: 11, color: "#94a3b8", flexShrink: 0, marginLeft: 8 }}>{a.time}</span>
                  </div>
                  <div style={{ fontSize: 12.5, color: "#64748b", marginTop: 1 }}>{a.desc}</div>
                  <div style={{ fontSize: 11.5, color: "#16a34a", marginTop: 1 }}>{a.sub}</div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => setPage("assignments")}
            style={{
              width: "100%",
              marginTop: 16,
              background: "#f8fafc",
              border: "1px solid #eef0f3",
              color: ORANGE,
              fontWeight: 700,
              fontSize: 13,
              padding: "10px",
              borderRadius: 8,
              cursor: "pointer",
            }}
          >
            View All Logs
          </button>
        </Card>
      </div>

      <div style={{ display: "flex", gap: 20 }}>
        <div style={{ background: NAVY, borderRadius: 12, padding: 22, flex: 1, color: "#fff" }}>
          <div style={{ fontWeight: 800, fontSize: 16 }}>Audit Due</div>
          <div style={{ fontSize: 13, color: "#94a3b8", marginTop: 8, lineHeight: 1.5 }}>
            Headquarters inventory audit is scheduled for in 3 days.
          </div>
        </div>
        <Card style={{ flex: 2 }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a" }}>Branches Overview</div>
            <button
              onClick={() => setPage("branches")}
              style={{ fontSize: 12.5, color: ORANGE, fontWeight: 700, border: "none", background: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}
            >
              View all <ChevronRight size={14} />
            </button>
          </div>
          <div style={{ display: "flex", gap: 24, marginTop: 16 }}>
            {branches.slice(0, 3).map((b) => (
              <div key={b.id} style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a" }}>{b.name}</div>
                <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>{b.assets.toLocaleString()} assets</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ===== from pages/Inventory.jsx ===== */
function Inventory() {
  const {
    assets,
    employees,
    returnAsset,
    inventoryStatusFilter,
    setInventoryStatusFilter,
    setPage,
    globalSearchQuery,
    setGlobalSearchQuery,
    setShowAddDeviceModal,
  } = useApp();
  const [tab, setTab] = useState("Laptops & PCs");
  const [showCsvPreview, setShowCsvPreview] = useState(false);
  const tabs = ["Laptops & PCs", "Monitors", "Printers", "Networking", "Peripherals"];

  // The Inventory search box and the global top-bar search share the same query,
  // so typing in either one filters this page's table.
  const query = globalSearchQuery;
  const setQuery = setGlobalSearchQuery;

  // If we arrived here from a Dashboard stat click, jump to the "All" view implicitly
  // by clearing the category tab restriction when a status filter is active.
  const statusFilter = inventoryStatusFilter;

  function empName(id) {
    const e = employees.find((e) => e.id === id);
    return e ? e.name : "—";
  }

  const categoryScoped = statusFilter ? assets : assets.filter((a) => a.category === tab);

  const filtered = categoryScoped.filter(
    (a) =>
      (!statusFilter || a.status === statusFilter) &&
      (query === "" ||
        a.model.toLowerCase().includes(query.toLowerCase()) ||
        a.serial.toLowerCase().includes(query.toLowerCase()) ||
        a.id.toLowerCase().includes(query.toLowerCase()) ||
        a.brand.toLowerCase().includes(query.toLowerCase()))
  );

  const scopeBase = statusFilter ? assets.filter((a) => a.status === statusFilter) : assets.filter((a) => a.category === tab);
  const total = scopeBase.length;
  const assigned = scopeBase.filter((a) => a.status === "Assigned").length;
  const inStock = scopeBase.filter((a) => a.status === "In Stock").length;
  const repair = scopeBase.filter((a) => a.status === "Repair").length;

  const csvHeaders = ["ASSET", "BRAND", "MODEL", "SERIAL NUMBER", "STATUS", "ASSIGNED TO", "BRANCH"];
  const csvRows = filtered.map((a) => ({
    ASSET: a.id,
    BRAND: a.brand,
    MODEL: a.model,
    "SERIAL NUMBER": a.serial,
    STATUS: a.status,
    "ASSIGNED TO": a.assignedTo ? empName(a.assignedTo) : "—",
    BRANCH: a.branch,
  }));
  const csvFilename = statusFilter ? `inventory_${statusFilter.toLowerCase().replace(/\s+/g, "_")}.csv` : `inventory_${tab.toLowerCase().replace(/\s+/g, "_").replace("&", "and")}.csv`;

  return (
    <div style={{ padding: 28 }}>
      <BackButton onClick={() => setPage("dashboard")} />
      <div style={{ fontSize: 12.5, color: "#94a3b8", marginBottom: 6, display: "flex", alignItems: "center", gap: 8 }}>
        Inventory &gt; {statusFilter ? `Status: ${statusFilter}` : tab}
        {statusFilter && (
          <button
            onClick={() => setInventoryStatusFilter(null)}
            style={{ display: "flex", alignItems: "center", gap: 4, border: "none", background: "#fef3e2", color: ORANGE, fontWeight: 700, fontSize: 11, padding: "3px 8px", borderRadius: 999, cursor: "pointer" }}
          >
            Clear filter <X size={11} />
          </button>
        )}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a" }}>System Inventory</div>
        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={() => setShowCsvPreview(true)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              border: "1px solid #eef0f3",
              borderRadius: 8,
              padding: "9px 16px",
              fontWeight: 700,
              fontSize: 13,
              color: "#475569",
              background: "#fff",
              cursor: "pointer",
            }}
          >
            <Download size={14} /> Export CSV
          </button>
          <button
            onClick={() => setShowAddDeviceModal(true)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              border: "none",
              borderRadius: 8,
              padding: "9px 16px",
              fontWeight: 700,
              fontSize: 13,
              color: "#fff",
              background: NAVY,
              cursor: "pointer",
            }}
          >
            <Plus size={14} /> Add Device
          </button>
        </div>
      </div>

      {!statusFilter && (
        <div style={{ display: "flex", gap: 4, borderBottom: "1px solid #eef0f3", marginBottom: 20 }}>
          {tabs.map((t) => {
            const count = assets.filter((a) => a.category === t).length;
            const active = t === tab;
            return (
              <button
                key={t}
                onClick={() => setTab(t)}
                style={{
                  padding: "10px 16px",
                  border: "none",
                  background: "none",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13.5,
                  color: active ? ORANGE : "#94a3b8",
                  borderBottom: active ? `2px solid ${ORANGE}` : "2px solid transparent",
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                }}
              >
                <CategoryIcon category={t} size={15} /> {t}
                <span
                  style={{
                    background: active ? "#fef3e2" : "#f1f5f9",
                    color: active ? ORANGE : "#94a3b8",
                    fontSize: 11,
                    fontWeight: 700,
                    padding: "1px 7px",
                    borderRadius: 999,
                  }}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      )}

      <div style={{ display: "flex", gap: 16, marginBottom: 20 }}>
        <StatCard icon={<Boxes size={17} color={NAVY} />} iconBg="#e2e8f0" label="TOTAL MANAGED" value={total} />
        <StatCard
          icon={<Users size={17} color="#475569" />}
          iconBg="#e2e8f0"
          label="ASSIGNED"
          value={assigned}
          sub={<div style={{ fontSize: 12, color: "#94a3b8" }}>{total ? Math.round((assigned / total) * 100) : 0}% util</div>}
        />
        <StatCard icon={<Building2 size={17} color="#475569" />} iconBg="#e2e8f0" label="IN STOCK" value={inStock} />
        <StatCard
          icon={<Wrench size={17} color="#dc2626" />}
          iconBg="#fee2e2"
          label="IN REPAIR"
          value={repair}
          danger
          sub={<div style={{ fontSize: 12, color: "#94a3b8" }}>Pending fix</div>}
        />
      </div>

      <Card style={{ padding: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 20px" }}>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by brand, model, serial, or asset ID..."
            style={{ border: "1px solid #eef0f3", borderRadius: 7, padding: "8px 12px", fontSize: 13, width: 320, outline: "none" }}
          />
          <div style={{ fontSize: 12.5, color: "#94a3b8" }}>
            Showing 1-{filtered.length} of {scopeBase.length} items
          </div>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#f8fafc", textAlign: "left" }}>
              {["ASSET", "BRAND", "MODEL", "SERIAL NUMBER", "STATUS", "ASSIGNED TO", "BRANCH", ""].map((h) => (
                <th key={h} style={{ padding: "10px 20px", fontSize: 11, color: "#94a3b8", fontWeight: 700, letterSpacing: 0.3, borderBottom: "1px solid #eef0f3" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((a) => (
              <tr key={a.id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                <td style={{ padding: "14px 20px", fontWeight: 700, fontSize: 13, color: NAVY }}>{a.id}</td>
                <td style={{ padding: "14px 20px", fontSize: 13, color: "#475569" }}>{a.brand}</td>
                <td style={{ padding: "14px 20px", fontSize: 13, color: "#0f172a" }}>{a.model}</td>
                <td style={{ padding: "14px 20px", fontSize: 12.5, color: "#94a3b8" }}>SN: {a.serial}</td>
                <td style={{ padding: "14px 20px" }}>
                  <StatusPill status={a.status} />
                </td>
                <td style={{ padding: "14px 20px", fontSize: 13, color: "#475569" }}>{a.assignedTo ? empName(a.assignedTo) : "—"}</td>
                <td style={{ padding: "14px 20px", fontSize: 13, color: "#475569" }}>{a.branch}</td>
                <td style={{ padding: "14px 20px" }}>
                  {a.status === "Assigned" ? (
                    <button onClick={() => returnAsset(a.id)} title="Return to stock" style={{ border: "none", background: "none", cursor: "pointer", color: "#94a3b8" }}>
                      <RotateCcw size={16} />
                    </button>
                  ) : (
                    <MoreVertical size={16} color="#94a3b8" />
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} style={{ padding: 40, textAlign: "center", color: "#94a3b8", fontSize: 13 }}>
                  No assets match your search{statusFilter ? "" : " in this category"}.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      {showCsvPreview && (
        <CsvPreviewModal onClose={() => setShowCsvPreview(false)} rows={csvRows} headers={csvHeaders} filename={csvFilename} />
      )}
    </div>
  );
}

/* ===== from pages/EmployeeDirectory.jsx ===== */
function EmployeeCard({ emp, assetCount, onOpen }) {
  return (
    <div
      onClick={onOpen}
      style={{
        background: "#fff",
        border: "1px solid #eef0f3",
        borderRadius: 12,
        padding: 18,
        cursor: "pointer",
        transition: "box-shadow .15s",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div
          style={{
            width: 42,
            height: 42,
            borderRadius: "50%",
            background: emp.avatarColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          {emp.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
        </div>
        <StatusPill status={emp.status} />
      </div>
      <div style={{ marginTop: 12, fontWeight: 800, fontSize: 15, color: "#0f172a" }}>{emp.name}</div>
      <div style={{ fontSize: 13, color: ORANGE, fontWeight: 600, marginTop: 2 }}>{emp.role}</div>
      <div style={{ fontSize: 12.5, color: "#94a3b8", marginTop: 2 }}>
        {emp.dept} · {emp.location}
      </div>
      <div style={{ fontSize: 10.5, color: "#94a3b8", fontWeight: 700, letterSpacing: 0.4, marginTop: 14, marginBottom: 6 }}>ASSIGNED ASSETS</div>
      {assetCount === 0 ? (
        <div style={{ fontSize: 12.5, color: "#94a3b8" }}>No assets assigned</div>
      ) : (
        <div style={{ fontSize: 12.5, color: "#475569" }}>
          {assetCount} item{assetCount > 1 ? "s" : ""}
        </div>
      )}
    </div>
  );
}

function EmployeeStatusFilterPopover({ statusFilter, setStatusFilter, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [onClose]);

  const options = [
    { key: null, label: "All" },
    { key: "Active", label: "Active" },
    { key: "On Leave", label: "On Leave" },
    { key: "Offboarded", label: "Offboarded" },
  ];

  return (
    <div
      ref={ref}
      style={{
        position: "absolute",
        top: "calc(100% + 8px)",
        right: 0,
        background: "#fff",
        border: "1px solid #eef0f3",
        borderRadius: 10,
        boxShadow: "0 12px 32px rgba(15,23,42,0.12)",
        width: 200,
        padding: 14,
        zIndex: 60,
      }}
    >
      <div style={{ fontSize: 11.5, fontWeight: 700, color: "#94a3b8", letterSpacing: 0.3, marginBottom: 10 }}>STATUS</div>
      {options.map((opt) => (
        <button
          key={opt.label}
          onClick={() => setStatusFilter(opt.key)}
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            border: "none",
            background: statusFilter === opt.key ? "#fef3e2" : "none",
            borderRadius: 7,
            padding: "8px 10px",
            fontSize: 13,
            fontWeight: 600,
            color: statusFilter === opt.key ? ORANGE : "#475569",
            cursor: "pointer",
            marginBottom: 2,
          }}
        >
          {opt.label}
          {statusFilter === opt.key && <Check size={14} />}
        </button>
      ))}
    </div>
  );
}

function EmployeeDirectory() {
  const {
    employees,
    assets,
    setSelectedEmployeeId,
    setPage,
    employeeSearchQuery,
    setEmployeeSearchQuery,
    employeeSort,
    setEmployeeSort,
  } = useApp();
  const [deptFilter, setDeptFilter] = useState("All Departments");
  const [statusFilter, setStatusFilter] = useState(null);
  const [showStatusFilter, setShowStatusFilter] = useState(false);
  const [showExportPreview, setShowExportPreview] = useState(false);
  const depts = ["All Departments", ...Array.from(new Set(employees.map((e) => e.dept)))];

  function assetCountFor(empId) {
    return assets.filter((a) => a.assignedTo === empId).length;
  }

  const query = employeeSearchQuery.trim().toLowerCase();

  let filtered = employees.filter(
    (e) =>
      (deptFilter === "All Departments" || e.dept === deptFilter) &&
      (!statusFilter || e.status === statusFilter) &&
      (query === "" ||
        e.name.toLowerCase().includes(query) ||
        e.role.toLowerCase().includes(query) ||
        e.id.includes(query) ||
        e.email.toLowerCase().includes(query))
  );

  const SORTERS = {
    "name-asc": (a, b) => a.name.localeCompare(b.name),
    "name-desc": (a, b) => b.name.localeCompare(a.name),
    "tenure-desc": (a, b) => parseFloat(b.tenure) - parseFloat(a.tenure),
    "tenure-asc": (a, b) => parseFloat(a.tenure) - parseFloat(b.tenure),
    "assets-desc": (a, b) => assetCountFor(b.id) - assetCountFor(a.id),
    "status-asc": (a, b) => a.status.localeCompare(b.status),
  };
  filtered = [...filtered].sort(SORTERS[employeeSort] || SORTERS["name-asc"]);

  function openEmployee(id) {
    setSelectedEmployeeId(id);
    setPage("employeeDetail");
  }

  const csvHeaders = ["EMPLOYEE ID", "NAME", "ROLE", "DEPARTMENT", "LOCATION", "STATUS", "TENURE", "ASSIGNED ASSETS"];
  const csvRows = filtered.map((e) => ({
    "EMPLOYEE ID": e.id,
    NAME: e.name,
    ROLE: e.role,
    DEPARTMENT: e.dept,
    LOCATION: e.location,
    STATUS: e.status,
    TENURE: e.tenure,
    "ASSIGNED ASSETS": assetCountFor(e.id),
  }));

  const activeFilterCount = (statusFilter ? 1 : 0) + (deptFilter !== "All Departments" ? 1 : 0);

  return (
    <div style={{ padding: 28 }}>
      <BackButton onClick={() => setPage("dashboard")} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
        <div>
          <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a" }}>Employee Directory</div>
          <div style={{ fontSize: 13, color: "#94a3b8", marginTop: 2 }}>
            Managing {employees.length} total staff across {depts.length - 1} departments
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, border: "1px solid #eef0f3", borderRadius: 8, padding: "0 12px", background: "#fff", width: 240 }}>
            <Search size={14} color="#94a3b8" />
            <input
              value={employeeSearchQuery}
              onChange={(e) => setEmployeeSearchQuery(e.target.value)}
              placeholder="Search employees..."
              style={{ border: "none", outline: "none", fontSize: 13, padding: "9px 0", width: "100%" }}
            />
          </div>
          <div style={{ position: "relative" }}>
            <button
              onClick={() => setShowStatusFilter((s) => !s)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 7,
                border: `1px solid ${activeFilterCount ? ORANGE : "#eef0f3"}`,
                borderRadius: 8,
                padding: "9px 16px",
                fontWeight: 700,
                fontSize: 13,
                color: activeFilterCount ? ORANGE : "#475569",
                background: activeFilterCount ? "#fef3e2" : "#fff",
                cursor: "pointer",
              }}
            >
              <Filter size={14} /> Filter {activeFilterCount > 0 && `(${activeFilterCount})`}
            </button>
            {showStatusFilter && (
              <EmployeeStatusFilterPopover statusFilter={statusFilter} setStatusFilter={setStatusFilter} onClose={() => setShowStatusFilter(false)} />
            )}
          </div>
          <select
            value={employeeSort}
            onChange={(e) => setEmployeeSort(e.target.value)}
            style={{
              border: "1px solid #eef0f3",
              borderRadius: 8,
              padding: "9px 12px",
              fontWeight: 700,
              fontSize: 13,
              color: "#475569",
              background: "#fff",
              cursor: "pointer",
            }}
          >
            <option value="name-asc">Sort: Name (A–Z)</option>
            <option value="name-desc">Sort: Name (Z–A)</option>
            <option value="tenure-desc">Sort: Tenure (longest)</option>
            <option value="tenure-asc">Sort: Tenure (shortest)</option>
            <option value="assets-desc">Sort: Most assets</option>
            <option value="status-asc">Sort: Status</option>
          </select>
          <button
            onClick={() => setShowExportPreview(true)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              border: "1px solid #eef0f3",
              borderRadius: 8,
              padding: "9px 16px",
              fontWeight: 700,
              fontSize: 13,
              color: "#475569",
              background: "#fff",
              cursor: "pointer",
            }}
          >
            <Download size={14} /> Export
          </button>
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 22, flexWrap: "wrap" }}>
        {depts.map((d) => (
          <button
            key={d}
            onClick={() => setDeptFilter(d)}
            style={{
              padding: "8px 16px",
              borderRadius: 999,
              border: "1px solid #eef0f3",
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 700,
              background: deptFilter === d ? ORANGE : "#fff",
              color: deptFilter === d ? "#fff" : "#475569",
            }}
          >
            {d}
          </button>
        ))}
      </div>

      <div style={{ fontSize: 12.5, color: "#94a3b8", marginBottom: 14 }}>
        Showing {filtered.length} of {employees.length} employees
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
        {filtered.map((emp) => {
          const count = assetCountFor(emp.id);
          return <EmployeeCard key={emp.id} emp={emp} assetCount={count} onOpen={() => openEmployee(emp.id)} />;
        })}
        {filtered.length === 0 && (
          <div style={{ gridColumn: "1 / -1", padding: 40, textAlign: "center", color: "#94a3b8", fontSize: 13, border: "1px solid #eef0f3", borderRadius: 12, background: "#fff" }}>
            No employees match your search or filters.
          </div>
        )}
      </div>

      {showExportPreview && (
        <CsvPreviewModal
          onClose={() => setShowExportPreview(false)}
          rows={csvRows}
          headers={csvHeaders}
          filename="employee_directory.csv"
          title="Export Employee Directory"
        />
      )}
    </div>
  );
}

/* ===== from pages/EmployeeDetail.jsx ===== */
function EmployeeDetail() {
  const { employees, assets, selectedEmployeeId, setPage, returnAsset } = useApp();
  const emp = employees.find((e) => e.id === selectedEmployeeId) || employees[0];
  const myAssets = assets.filter((a) => a.assignedTo === emp.id);

  return (
    <div style={{ padding: 28 }}>
      <button
        onClick={() => setPage("employees")}
        style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "none", color: ORANGE, fontWeight: 700, fontSize: 13.5, cursor: "pointer", marginBottom: 18 }}
      >
        <ArrowLeft size={15} /> Back to Directory
      </button>

      <div style={{ display: "flex", gap: 20 }}>
        <Card style={{ width: 280, flexShrink: 0, textAlign: "center" }}>
          <div
            style={{
              width: 76,
              height: 76,
              borderRadius: "50%",
              background: emp.avatarColor,
              margin: "0 auto",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              fontWeight: 700,
              fontSize: 24,
            }}
          >
            {emp.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
          </div>
          <div style={{ marginTop: 14, fontWeight: 800, fontSize: 17, color: "#0f172a" }}>{emp.name}</div>
          <div style={{ fontSize: 13, color: ORANGE, fontWeight: 600, marginTop: 2 }}>{emp.role}</div>
          <div style={{ marginTop: 10 }}>
            <StatusPill status={emp.status} />
          </div>

          <div style={{ borderTop: "1px solid #eef0f3", marginTop: 18, paddingTop: 16, textAlign: "left", display: "flex", flexDirection: "column", gap: 10 }}>
            <Row label="Tenure" value={emp.tenure} />
            <Row label="Department" value={emp.dept} />
            <Row label="Location" value={emp.location} />
            <Row label="Employee ID" value={`EMP-${emp.id}`} />
          </div>

          <div style={{ borderTop: "1px solid #eef0f3", marginTop: 16, paddingTop: 16, display: "flex", flexDirection: "column", gap: 8 }}>
            <button
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                border: "1px solid #eef0f3",
                borderRadius: 8,
                padding: "10px 14px",
                background: "#fff",
                fontSize: 13,
                fontWeight: 700,
                color: "#475569",
                cursor: "pointer",
              }}
            >
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <Key size={14} /> Reset Password
              </span>
              <ChevronRight size={14} />
            </button>
            <button
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                border: "1px solid #eef0f3",
                borderRadius: 8,
                padding: "10px 14px",
                background: "#fff",
                fontSize: 13,
                fontWeight: 700,
                color: "#475569",
                cursor: "pointer",
              }}
            >
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <History size={14} /> Access Logs
              </span>
              <ChevronRight size={14} />
            </button>
          </div>
        </Card>

        <Card style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a", marginBottom: 2 }}>Personal Information</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 16, marginBottom: 24 }}>
            <Field label="Full Name" value={emp.name} />
            <Field label="Email Address" value={emp.email} />
            <Field label="Department" value={emp.dept} />
            <Field label="Office Location" value={emp.location} />
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a" }}>Currently Assigned Assets</div>
            <button
              onClick={() => setPage("newAssignment")}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                border: "1px solid #fde6c2",
                background: "#fef3e2",
                color: ORANGE,
                fontWeight: 700,
                fontSize: 12.5,
                padding: "8px 14px",
                borderRadius: 8,
                cursor: "pointer",
              }}
            >
              <Plus size={13} /> Assign New
            </button>
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ textAlign: "left" }}>
                {["ASSET ITEM", "SERIAL NUMBER", "STATUS", "ACTIONS"].map((h) => (
                  <th key={h} style={{ padding: "8px 0", fontSize: 11, color: "#94a3b8", fontWeight: 700, borderBottom: "1px solid #eef0f3" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {myAssets.map((a) => (
                <tr key={a.id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                  <td style={{ padding: "12px 0", display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 30, height: 30, borderRadius: 7, background: "#f1f5f9", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <CategoryIcon category={a.category} size={14} />
                    </div>
                    <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{a.model}</span>
                  </td>
                  <td style={{ fontSize: 12.5, color: "#94a3b8" }}>{a.serial}</td>
                  <td>
                    <StatusPill status={a.status} />
                  </td>
                  <td>
                    <button onClick={() => returnAsset(a.id)} style={{ border: "none", background: "none", color: "#dc2626", fontWeight: 700, fontSize: 12.5, cursor: "pointer" }}>
                      Deassign
                    </button>
                  </td>
                </tr>
              ))}
              {myAssets.length === 0 && (
                <tr>
                  <td colSpan={4} style={{ padding: "24px 0", color: "#94a3b8", fontSize: 13 }}>
                    No assets currently assigned.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

/* ===== from pages/Branches.jsx ===== */
function FilterPopover({ healthFilter, setHealthFilter, deptFilter, setDeptFilter, allDepts, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [onClose]);

  return (
    <div
      ref={ref}
      style={{
        position: "absolute",
        top: "calc(100% + 8px)",
        right: 0,
        background: "#fff",
        border: "1px solid #eef0f3",
        borderRadius: 10,
        boxShadow: "0 12px 32px rgba(15,23,42,0.12)",
        width: 240,
        padding: 16,
        zIndex: 60,
      }}
    >
      <div style={{ fontSize: 11.5, fontWeight: 700, color: "#94a3b8", letterSpacing: 0.3, marginBottom: 10 }}>HEALTH STATUS</div>
      {[
        { key: null, label: "All" },
        { key: "good", label: "Healthy" },
        { key: "warning", label: "Needs Attention" },
      ].map((opt) => (
        <button
          key={opt.label}
          onClick={() => setHealthFilter(opt.key)}
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            border: "none",
            background: healthFilter === opt.key ? "#fef3e2" : "none",
            borderRadius: 7,
            padding: "8px 10px",
            fontSize: 13,
            fontWeight: 600,
            color: healthFilter === opt.key ? ORANGE : "#475569",
            cursor: "pointer",
            marginBottom: 2,
          }}
        >
          {opt.label}
          {healthFilter === opt.key && <Check size={14} />}
        </button>
      ))}

      <div style={{ fontSize: 11.5, fontWeight: 700, color: "#94a3b8", letterSpacing: 0.3, margin: "14px 0 10px" }}>DEPARTMENT</div>
      <button
        onClick={() => setDeptFilter(null)}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          border: "none",
          background: deptFilter === null ? "#fef3e2" : "none",
          borderRadius: 7,
          padding: "8px 10px",
          fontSize: 13,
          fontWeight: 600,
          color: deptFilter === null ? ORANGE : "#475569",
          cursor: "pointer",
          marginBottom: 2,
        }}
      >
        All
        {deptFilter === null && <Check size={14} />}
      </button>
      {allDepts.map((d) => (
        <button
          key={d}
          onClick={() => setDeptFilter(d)}
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            border: "none",
            background: deptFilter === d ? "#fef3e2" : "none",
            borderRadius: 7,
            padding: "8px 10px",
            fontSize: 13,
            fontWeight: 600,
            color: deptFilter === d ? ORANGE : "#475569",
            cursor: "pointer",
            marginBottom: 2,
          }}
        >
          {d}
          {deptFilter === d && <Check size={14} />}
        </button>
      ))}
    </div>
  );
}

function Branches() {
  const { branches, setPage, setSelectedBranchId } = useApp();
  const [healthFilter, setHealthFilter] = useState(null);
  const [deptFilter, setDeptFilter] = useState(null);
  const [showFilter, setShowFilter] = useState(false);
  const [showCsvPreview, setShowCsvPreview] = useState(false);

  const allDepts = Array.from(new Set(branches.flatMap((b) => b.departments))).sort();

  const filteredBranches = branches.filter(
    (b) => (!healthFilter || b.health === healthFilter) && (!deptFilter || b.departments.includes(deptFilter))
  );

  const totalAssets = filteredBranches.reduce((s, b) => s + b.assets, 0);
  const totalDepts = new Set(filteredBranches.flatMap((b) => b.departments)).size;
  const activePct = filteredBranches.length ? Math.round((filteredBranches.filter((b) => b.health === "good").length / filteredBranches.length) * 100) : 0;

  function openBranch(id) {
    setSelectedBranchId(id);
    setPage("branchDetail");
  }

  const csvHeaders = ["BRANCH ID", "BRANCH NAME", "REGION", "DEPARTMENTS", "ASSETS", "HEALTH"];
  const csvRows = filteredBranches.map((b) => ({
    "BRANCH ID": b.id,
    "BRANCH NAME": b.name,
    REGION: b.region,
    DEPARTMENTS: b.departments.join("; "),
    ASSETS: b.assets,
    HEALTH: b.health === "good" ? "Healthy" : "Needs Attention",
  }));

  const activeFilterCount = (healthFilter ? 1 : 0) + (deptFilter ? 1 : 0);

  return (
    <div style={{ padding: 28 }}>
      <BackButton onClick={() => setPage("dashboard")} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a" }}>Branches & Departments</div>
          <div style={{ fontSize: 13, color: "#94a3b8", marginTop: 2 }}>
            Operational overview of all {branches.length} regional hubs and department allocation.
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ position: "relative" }}>
            <button
              onClick={() => setShowFilter((s) => !s)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 7,
                border: `1px solid ${activeFilterCount ? ORANGE : "#eef0f3"}`,
                borderRadius: 8,
                padding: "9px 16px",
                fontWeight: 700,
                fontSize: 13,
                color: activeFilterCount ? ORANGE : "#475569",
                background: activeFilterCount ? "#fef3e2" : "#fff",
                cursor: "pointer",
              }}
            >
              <Filter size={14} /> Filter {activeFilterCount > 0 && `(${activeFilterCount})`}
            </button>
            {showFilter && (
              <FilterPopover
                healthFilter={healthFilter}
                setHealthFilter={setHealthFilter}
                deptFilter={deptFilter}
                setDeptFilter={setDeptFilter}
                allDepts={allDepts}
                onClose={() => setShowFilter(false)}
              />
            )}
          </div>
          <button
            onClick={() => setShowCsvPreview(true)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              border: "none",
              borderRadius: 8,
              padding: "9px 16px",
              fontWeight: 700,
              fontSize: 13,
              color: "#fff",
              background: NAVY,
              cursor: "pointer",
            }}
          >
            <Download size={14} /> Export Data
          </button>
        </div>
      </div>

      <div style={{ display: "flex", gap: 16, marginBottom: 20 }}>
        <StatCard icon={<Building2 size={17} color={NAVY} />} iconBg="#e2e8f0" label="TOTAL BRANCHES" value={filteredBranches.length} />
        <StatCard icon={<Boxes size={17} color="#475569" />} iconBg="#e2e8f0" label="TOTAL DEPARTMENTS" value={totalDepts} />
        <StatCard icon={<ClipboardCheck size={17} color="#475569" />} iconBg="#e2e8f0" label="MANAGED ASSETS" value={totalAssets.toLocaleString()} />
        <StatCard icon={<CheckCircle2 size={17} color="#16a34a" />} iconBg="#dcfce7" label="ACTIVE STATUS" value={`${activePct}%`} />
      </div>

      <div style={{ display: "flex", gap: 20 }}>
        <Card style={{ flex: 2, padding: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 20px" }}>
            <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a" }}>Branch Inventory Index</div>
            <span style={{ fontSize: 12, color: "#94a3b8", background: "#f1f5f9", padding: "4px 10px", borderRadius: 999 }}>
              Displaying {filteredBranches.length} region{filteredBranches.length === 1 ? "" : "s"}
            </span>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ textAlign: "left" }}>
                {["BRANCH NAME", "DEPARTMENTS", "ASSETS", "HEALTH", ""].map((h) => (
                  <th key={h} style={{ padding: "8px 20px", fontSize: 11, color: "#94a3b8", fontWeight: 700, borderBottom: "1px solid #eef0f3" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredBranches.map((b) => (
                <tr
                  key={b.id}
                  onClick={() => openBranch(b.id)}
                  style={{ borderBottom: "1px solid #f3f4f6", cursor: "pointer" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#fafbfc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <td style={{ padding: "14px 20px", display: "flex", alignItems: "center", gap: 10 }}>
                    <div
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: 7,
                        background: NAVY,
                        color: "#fff",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 11,
                        fontWeight: 700,
                      }}
                    >
                      {b.id}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{b.name}</div>
                      <div style={{ fontSize: 11.5, color: "#94a3b8" }}>{b.region}</div>
                    </div>
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <div style={{ display: "flex", gap: 5 }}>
                      {b.departments.slice(0, 2).map((d) => (
                        <span key={d} style={{ background: "#fef3e2", color: ORANGE, fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 999 }}>
                          {d}
                        </span>
                      ))}
                      {b.departments.length > 2 && (
                        <span style={{ background: "#f1f5f9", color: "#94a3b8", fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 999 }}>
                          +{b.departments.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td style={{ padding: "14px 20px", fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{b.assets.toLocaleString()}</td>
                  <td style={{ padding: "14px 20px" }}>
                    <span
                      style={{
                        width: 9,
                        height: 9,
                        borderRadius: 99,
                        display: "inline-block",
                        background: b.health === "good" ? "#16a34a" : "#f59e0b",
                      }}
                    />
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <ChevronRight size={15} color="#cbd5e1" />
                  </td>
                </tr>
              ))}
              {filteredBranches.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ padding: 30, textAlign: "center", color: "#94a3b8", fontSize: 13 }}>
                    No branches match the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </Card>

        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 16 }}>
          <Card>
            <div style={{ fontWeight: 800, fontSize: 15, color: "#0f172a", marginBottom: 14 }}>Asset Distribution</div>
            {[
              { label: "LOGISTICS", pct: 42, color: ORANGE },
              { label: "OPERATIONS", pct: 31, color: NAVY },
              { label: "IT", pct: 18, color: "#0f172a" },
              { label: "HR & ADMIN", pct: 9, color: "#cbd5e1" },
            ].map((d) => (
              <div key={d.label} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 5 }}>
                  <span style={{ color: "#64748b", fontWeight: 700 }}>{d.label}</span>
                  <span style={{ color: "#94a3b8" }}>{d.pct}%</span>
                </div>
                <div style={{ height: 6, borderRadius: 99, background: "#eef0f3", overflow: "hidden" }}>
                  <div style={{ width: `${d.pct}%`, height: "100%", background: d.color }} />
                </div>
              </div>
            ))}
          </Card>

          <Card>
            <div style={{ fontWeight: 800, fontSize: 15, color: "#0f172a", marginBottom: 14 }}>Recent Maintenance Alerts</div>
            <button
              onClick={() => {
                const wn = branches.find((b) => b.name.includes("Wadi"));
                if (wn) openBranch(wn.id);
              }}
              style={{ display: "flex", gap: 10, marginBottom: 12, border: "none", background: "none", cursor: "pointer", textAlign: "left", width: "100%", padding: 0 }}
            >
              <AlertTriangle size={16} color="#f59e0b" style={{ flexShrink: 0, marginTop: 2 }} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>Wadi El Natrun Hub</div>
                <div style={{ fontSize: 12, color: "#94a3b8" }}>5 unassigned IT assets detected.</div>
              </div>
            </button>
            <button
              onClick={() => {
                const ap = branches.find((b) => b.name.includes("Alexandria"));
                if (ap) openBranch(ap.id);
              }}
              style={{ display: "flex", gap: 10, border: "none", background: "none", cursor: "pointer", textAlign: "left", width: "100%", padding: 0 }}
            >
              <CheckCircle2 size={16} color="#16a34a" style={{ flexShrink: 0, marginTop: 2 }} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>Alexandria Port</div>
                <div style={{ fontSize: 12, color: "#94a3b8" }}>New shipment of 12 mobile units received.</div>
              </div>
            </button>
          </Card>
        </div>
      </div>

      {showCsvPreview && (
        <CsvPreviewModal onClose={() => setShowCsvPreview(false)} rows={csvRows} headers={csvHeaders} filename="branches_export.csv" />
      )}
    </div>
  );
}

/* ===== from pages/BranchDetail.jsx ===== */
function BranchDetail() {
  const { branches, assets, employees, selectedBranchId, setPage } = useApp();
  const branch = branches.find((b) => b.id === selectedBranchId) || branches[0];

  // Our seed assets use full branch names like "London HQ"; match loosely against the branch name.
  const branchAssets = assets.filter((a) => a.branch && branch.name && a.branch.toLowerCase().includes(branch.name.split(" ")[0].toLowerCase()));

  function empName(id) {
    const e = employees.find((e) => e.id === id);
    return e ? e.name : "—";
  }

  return (
    <div style={{ padding: 28 }}>
      <button
        onClick={() => setPage("branches")}
        style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "none", color: ORANGE, fontWeight: 700, fontSize: 13.5, cursor: "pointer", marginBottom: 18 }}
      >
        <ArrowLeft size={15} /> Back to Branches
      </button>

      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
        <div
          style={{
            width: 46,
            height: 46,
            borderRadius: 10,
            background: NAVY,
            color: "#fff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 800,
            fontSize: 14,
          }}
        >
          {branch.id}
        </div>
        <div>
          <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a" }}>{branch.name}</div>
          <div style={{ fontSize: 13, color: "#94a3b8" }}>{branch.region}</div>
        </div>
        <span
          style={{
            marginLeft: "auto",
            display: "flex",
            alignItems: "center",
            gap: 6,
            fontSize: 12.5,
            fontWeight: 700,
            color: branch.health === "good" ? "#16a34a" : "#b45309",
            background: branch.health === "good" ? "#dcfce7" : "#fef3c7",
            padding: "6px 12px",
            borderRadius: 999,
          }}
        >
          <span style={{ width: 8, height: 8, borderRadius: 99, background: branch.health === "good" ? "#16a34a" : "#f59e0b" }} />
          {branch.health === "good" ? "Healthy" : "Needs Attention"}
        </span>
      </div>

      <div style={{ display: "flex", gap: 16, marginBottom: 20 }}>
        <StatCard icon={<Boxes size={17} color={NAVY} />} iconBg="#e2e8f0" label="MANAGED ASSETS" value={branch.assets.toLocaleString()} />
        <StatCard icon={<Users size={17} color="#475569" />} iconBg="#e2e8f0" label="DEPARTMENTS" value={branch.departments.length} />
        <StatCard icon={<ClipboardCheck size={17} color="#475569" />} iconBg="#e2e8f0" label="LOCAL INVENTORY MATCHES" value={branchAssets.length} />
      </div>

      <Card>
        <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a", marginBottom: 4 }}>Departments</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 22, marginTop: 12 }}>
          {branch.departments.map((d) => (
            <span key={d} style={{ background: "#fef3e2", color: ORANGE, fontSize: 12, fontWeight: 700, padding: "5px 12px", borderRadius: 999 }}>
              {d}
            </span>
          ))}
        </div>

        <div style={{ fontWeight: 800, fontSize: 16, color: "#0f172a", marginBottom: 12 }}>Assets at this branch</div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ textAlign: "left" }}>
              {["ASSET", "MODEL", "STATUS", "ASSIGNED TO"].map((h) => (
                <th key={h} style={{ padding: "8px 0", fontSize: 11, color: "#94a3b8", fontWeight: 700, borderBottom: "1px solid #eef0f3" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {branchAssets.map((a) => (
              <tr key={a.id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                <td style={{ padding: "12px 0", display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 7, background: "#f1f5f9", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <CategoryIcon category={a.category} size={14} />
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{a.id}</span>
                </td>
                <td style={{ fontSize: 13, color: "#475569" }}>{a.brand} {a.model}</td>
                <td><StatusPill status={a.status} /></td>
                <td style={{ fontSize: 13, color: "#475569" }}>{a.assignedTo ? empName(a.assignedTo) : "—"}</td>
              </tr>
            ))}
            {branchAssets.length === 0 && (
              <tr>
                <td colSpan={4} style={{ padding: "24px 0", color: "#94a3b8", fontSize: 13 }}>
                  No inventory records directly matched to this branch yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ===== from pages/NewAssignment.jsx ===== */
function NewAssignment() {
  const { employees, assets, branches, assignAsset, setPage } = useApp();
  const [step, setStep] = useState(1);
  const [recipientType, setRecipientType] = useState("employee");
  const [query, setQuery] = useState("");
  const [selectedEmp, setSelectedEmp] = useState(null);
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [selectedDept, setSelectedDept] = useState(null);
  const [selectedAssetId, setSelectedAssetId] = useState(null);

  const candidates = employees.filter((e) => query === "" || e.name.toLowerCase().includes(query.toLowerCase()) || e.id.includes(query));
  const branchCandidates = branches.filter(
    (b) => query === "" || b.name.toLowerCase().includes(query.toLowerCase()) || b.id.toLowerCase().includes(query.toLowerCase())
  );
  const availableAssets = assets.filter((a) => a.status === "In Stock");

  const hasValidRecipient = recipientType === "employee" ? !!selectedEmp : !!selectedBranch;

  function goNext() {
    if (step === 3) {
      if (recipientType === "employee") {
        assignAsset(selectedAssetId, { type: "employee", employeeId: selectedEmp.id });
      } else {
        assignAsset(selectedAssetId, { type: "branch", branchId: selectedBranch.id, departmentName: selectedDept });
      }
      setPage("contract");
    } else {
      setStep(step + 1);
    }
  }

  function switchRecipientType(key) {
    setRecipientType(key);
    setSelectedEmp(null);
    setSelectedBranch(null);
    setSelectedDept(null);
    setQuery("");
  }

  const steps = [
    { n: 1, label: "RECIPIENT", sub: "Identity Selection" },
    { n: 2, label: "ASSETS", sub: "Inventory Selection" },
    { n: 3, label: "LOGISTICS", sub: "Review & Confirm" },
  ];

  const selectedAsset = assets.find((a) => a.id === selectedAssetId);

  return (
    <div style={{ padding: 28, maxWidth: 760 }}>
      <button
        onClick={() => setPage("dashboard")}
        style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "none", color: ORANGE, fontWeight: 700, fontSize: 13.5, cursor: "pointer", marginBottom: 14 }}
      >
        <ArrowLeft size={15} /> Back
      </button>
      <div style={{ fontSize: 12.5, color: "#94a3b8", marginBottom: 6 }}>
        Asset Central &nbsp;&nbsp;<span style={{ color: ORANGE, fontWeight: 700 }}>New Assignment</span> &nbsp;&nbsp;Batch Returns
      </div>
      <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a", marginTop: 12 }}>Hardware Checkout</div>
      <div style={{ fontSize: 13.5, color: "#94a3b8", marginTop: 2, marginBottom: 26 }}>
        Assign technology assets to employees or organizational branches.
      </div>

      <div style={{ display: "flex", alignItems: "center", marginBottom: 28 }}>
        {steps.map((s, i) => (
          <React.Fragment key={s.n}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: step >= s.n ? NAVY : "#f1f5f9",
                  color: step >= s.n ? "#fff" : "#94a3b8",
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                {step > s.n ? <Check size={15} /> : s.n}
              </div>
              <div>
                <div style={{ fontSize: 11.5, fontWeight: 800, color: step >= s.n ? "#0f172a" : "#94a3b8", letterSpacing: 0.4 }}>{s.label}</div>
                <div style={{ fontSize: 11, color: "#94a3b8" }}>{s.sub}</div>
              </div>
            </div>
            {i < steps.length - 1 && <div style={{ flex: 1, height: 1, background: "#eef0f3", margin: "0 14px" }} />}
          </React.Fragment>
        ))}
      </div>

      {step === 1 && (
        <>
          <div style={{ display: "flex", gap: 14, marginBottom: 22 }}>
            {[
              { key: "employee", title: "Individual Employee", desc: "Assign assets directly to a specific team member.", icon: <Users size={18} /> },
              { key: "branch", title: "Dept / Branch", desc: "Assign assets to a physical location or department pool.", icon: <Building2 size={18} /> },
            ].map((opt) => (
              <div
                key={opt.key}
                onClick={() => switchRecipientType(opt.key)}
                style={{
                  flex: 1,
                  border: `1.5px solid ${recipientType === opt.key ? ORANGE : "#eef0f3"}`,
                  borderRadius: 10,
                  padding: 18,
                  cursor: "pointer",
                  position: "relative",
                  background: recipientType === opt.key ? "#fffaf3" : "#fff",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: "#eef0f3", display: "flex", alignItems: "center", justifyContent: "center", color: "#475569" }}>
                    {opt.icon}
                  </div>
                  <div
                    style={{
                      width: 18,
                      height: 18,
                      borderRadius: "50%",
                      border: `2px solid ${recipientType === opt.key ? ORANGE : "#cbd5e1"}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {recipientType === opt.key && <div style={{ width: 9, height: 9, borderRadius: "50%", background: ORANGE }} />}
                  </div>
                </div>
                <div style={{ fontWeight: 800, fontSize: 14.5, color: "#0f172a", marginTop: 12 }}>{opt.title}</div>
                <div style={{ fontSize: 12.5, color: "#94a3b8", marginTop: 4 }}>{opt.desc}</div>
              </div>
            ))}
          </div>

          {recipientType === "employee" ? (
            <>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 8 }}>Search Recipient Name or ID</div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, border: "1px solid #eef0f3", borderRadius: 8, padding: "10px 14px", marginBottom: 14 }}>
                <Search size={15} color="#94a3b8" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g. Marcus Thorne or EMP ID..."
                  style={{ border: "none", outline: "none", fontSize: 13.5, width: "100%" }}
                />
              </div>

              <div style={{ border: "1px solid #eef0f3", borderRadius: 10, overflow: "hidden" }}>
                {candidates.slice(0, 5).map((e) => (
                  <div
                    key={e.id}
                    onClick={() => setSelectedEmp(e)}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "12px 16px",
                      borderBottom: "1px solid #f3f4f6",
                      cursor: "pointer",
                      background: selectedEmp?.id === e.id ? "#fffaf3" : "#fff",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div
                        style={{
                          width: 34,
                          height: 34,
                          borderRadius: "50%",
                          background: e.avatarColor,
                          color: "#fff",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontWeight: 700,
                          fontSize: 12,
                        }}
                      >
                        {e.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
                      </div>
                      <div>
                        <div style={{ fontSize: 13.5, fontWeight: 700, color: "#0f172a" }}>{e.name}</div>
                        <div style={{ fontSize: 12, color: "#94a3b8" }}>
                          {e.role} · ID: {e.id}
                        </div>
                      </div>
                    </div>
                    {selectedEmp?.id === e.id && (
                      <div style={{ width: 22, height: 22, borderRadius: "50%", background: ORANGE, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Check size={13} color="#fff" />
                      </div>
                    )}
                  </div>
                ))}
                {candidates.length === 0 && <div style={{ padding: 20, fontSize: 13, color: "#94a3b8", textAlign: "center" }}>No matching employees.</div>}
              </div>
            </>
          ) : (
            <>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 8 }}>Search Branch Name or ID</div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, border: "1px solid #eef0f3", borderRadius: 8, padding: "10px 14px", marginBottom: 14 }}>
                <Search size={15} color="#94a3b8" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g. Sadat City or HQ..."
                  style={{ border: "none", outline: "none", fontSize: 13.5, width: "100%" }}
                />
              </div>

              <div style={{ border: "1px solid #eef0f3", borderRadius: 10, overflow: "hidden", marginBottom: selectedBranch ? 16 : 0 }}>
                {branchCandidates.slice(0, 6).map((b) => (
                  <div
                    key={b.id}
                    onClick={() => {
                      setSelectedBranch(b);
                      setSelectedDept(null);
                    }}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "12px 16px",
                      borderBottom: "1px solid #f3f4f6",
                      cursor: "pointer",
                      background: selectedBranch?.id === b.id ? "#fffaf3" : "#fff",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div
                        style={{
                          width: 34,
                          height: 34,
                          borderRadius: 8,
                          background: NAVY,
                          color: "#fff",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontWeight: 700,
                          fontSize: 11,
                        }}
                      >
                        {b.id}
                      </div>
                      <div>
                        <div style={{ fontSize: 13.5, fontWeight: 700, color: "#0f172a" }}>{b.name}</div>
                        <div style={{ fontSize: 12, color: "#94a3b8" }}>{b.region}</div>
                      </div>
                    </div>
                    {selectedBranch?.id === b.id && (
                      <div style={{ width: 22, height: 22, borderRadius: "50%", background: ORANGE, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Check size={13} color="#fff" />
                      </div>
                    )}
                  </div>
                ))}
                {branchCandidates.length === 0 && <div style={{ padding: 20, fontSize: 13, color: "#94a3b8", textAlign: "center" }}>No matching branches.</div>}
              </div>

              {selectedBranch && (
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 8 }}>
                    Department within {selectedBranch.name} <span style={{ color: "#94a3b8", fontWeight: 500 }}>(optional)</span>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button
                      onClick={() => setSelectedDept(null)}
                      style={{
                        padding: "8px 14px",
                        borderRadius: 999,
                        border: "1px solid #eef0f3",
                        cursor: "pointer",
                        fontSize: 12.5,
                        fontWeight: 700,
                        background: selectedDept === null ? ORANGE : "#fff",
                        color: selectedDept === null ? "#fff" : "#475569",
                      }}
                    >
                      Whole Branch
                    </button>
                    {selectedBranch.departments.map((d) => (
                      <button
                        key={d}
                        onClick={() => setSelectedDept(d)}
                        style={{
                          padding: "8px 14px",
                          borderRadius: 999,
                          border: "1px solid #eef0f3",
                          cursor: "pointer",
                          fontSize: 12.5,
                          fontWeight: 700,
                          background: selectedDept === d ? ORANGE : "#fff",
                          color: selectedDept === d ? "#fff" : "#475569",
                        }}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </>
      )}

      {step === 2 && (
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 10 }}>Select an available asset from stock</div>
          <div style={{ border: "1px solid #eef0f3", borderRadius: 10, overflow: "hidden" }}>
            {availableAssets.map((a) => (
              <div
                key={a.id}
                onClick={() => setSelectedAssetId(a.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "14px 16px",
                  borderBottom: "1px solid #f3f4f6",
                  cursor: "pointer",
                  background: selectedAssetId === a.id ? "#fffaf3" : "#fff",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: "#f1f5f9", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <CategoryIcon category={a.category} size={16} />
                  </div>
                  <div>
                    <div style={{ fontSize: 13.5, fontWeight: 700, color: "#0f172a" }}>
                      {a.brand} {a.model}
                    </div>
                    <div style={{ fontSize: 12, color: "#94a3b8" }}>
                      SN: {a.serial} · {a.branch}
                    </div>
                  </div>
                </div>
                {selectedAssetId === a.id && (
                  <div style={{ width: 22, height: 22, borderRadius: "50%", background: ORANGE, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Check size={13} color="#fff" />
                  </div>
                )}
              </div>
            ))}
            {availableAssets.length === 0 && <div style={{ padding: 20, fontSize: 13, color: "#94a3b8", textAlign: "center" }}>No assets currently in stock.</div>}
          </div>
        </div>
      )}

      {step === 3 && hasValidRecipient && selectedAsset && (
        <Card>
          <div style={{ fontWeight: 800, fontSize: 15, color: "#0f172a", marginBottom: 16 }}>Review Assignment</div>
          {recipientType === "employee" ? (
            <>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #f3f4f6" }}>
                <span style={{ fontSize: 13, color: "#94a3b8" }}>Recipient</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>
                  {selectedEmp.name} ({selectedEmp.role})
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #f3f4f6" }}>
                <span style={{ fontSize: 13, color: "#94a3b8" }}>Location</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{selectedEmp.location}</span>
              </div>
            </>
          ) : (
            <>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #f3f4f6" }}>
                <span style={{ fontSize: 13, color: "#94a3b8" }}>Recipient</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>
                  {selectedBranch.name}
                  {selectedDept ? ` — ${selectedDept} Dept.` : " (Whole Branch)"}
                </span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #f3f4f6" }}>
                <span style={{ fontSize: 13, color: "#94a3b8" }}>Region</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{selectedBranch.region}</span>
              </div>
            </>
          )}
          <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #f3f4f6" }}>
            <span style={{ fontSize: 13, color: "#94a3b8" }}>Asset</span>
            <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>
              {selectedAsset.brand} {selectedAsset.model}
            </span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0" }}>
            <span style={{ fontSize: 13, color: "#94a3b8" }}>Serial Number</span>
            <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{selectedAsset.serial}</span>
          </div>
          <div style={{ marginTop: 14, background: "#fef3e2", borderRadius: 8, padding: "10px 14px", fontSize: 12.5, color: "#b45309" }}>
            Confirming will mark this asset as Assigned and generate a delivery contract.
          </div>
        </Card>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 26 }}>
        <button
          onClick={() => (step === 1 ? setPage("dashboard") : setStep(step - 1))}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            border: "1px solid #eef0f3",
            background: "#fff",
            color: "#475569",
            fontWeight: 700,
            fontSize: 13.5,
            padding: "11px 20px",
            borderRadius: 8,
            cursor: "pointer",
          }}
        >
          <ChevronLeft size={15} /> Back
        </button>
        <button
          onClick={goNext}
          disabled={(step === 1 && !hasValidRecipient) || (step === 2 && !selectedAssetId)}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            border: "none",
            color: "#fff",
            fontWeight: 700,
            fontSize: 13.5,
            padding: "11px 22px",
            borderRadius: 8,
            cursor: "pointer",
            background: (step === 1 && !hasValidRecipient) || (step === 2 && !selectedAssetId) ? "#fcd9a8" : ORANGE,
          }}
        >
          {step === 3 ? "Confirm & Generate Contract" : "Next Step"} <ChevronRight size={15} />
        </button>
      </div>
    </div>
  );
}

/* ===== from pages/ContractPreview.jsx ===== */
function ContractPreview() {
  const { lastContract, setPage } = useApp();

  if (!lastContract) {
    return (
      <div style={{ padding: 60, textAlign: "center" }}>
        <FileText size={36} color="#cbd5e1" />
        <div style={{ marginTop: 12, color: "#94a3b8", fontSize: 14 }}>No contract has been generated yet.</div>
        <button
          onClick={() => setPage("newAssignment")}
          style={{ marginTop: 16, background: ORANGE, color: "#fff", border: "none", borderRadius: 8, padding: "10px 20px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}
        >
          Start New Assignment
        </button>
      </div>
    );
  }

  const { docId, date, employee, branchRecipient, asset, officer } = lastContract;

  return (
    <div style={{ padding: 28, maxWidth: 800 }}>
      <button
        onClick={() => setPage("assignments")}
        style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "none", color: ORANGE, fontWeight: 700, fontSize: 13.5, cursor: "pointer", marginBottom: 14 }}
      >
        <ArrowLeft size={15} /> Back
      </button>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 12.5, color: "#94a3b8" }}>Asset Central</div>
          <div style={{ fontWeight: 800, fontSize: 18, color: "#0f172a" }}>Delivery Contract #{docId}</div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={() => setPage("newAssignment")}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              border: "1px solid #eef0f3",
              borderRadius: 8,
              padding: "9px 16px",
              fontWeight: 700,
              fontSize: 13,
              color: "#475569",
              background: "#fff",
              cursor: "pointer",
            }}
          >
            Edit Details
          </button>
          <button
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              border: "none",
              borderRadius: 8,
              padding: "9px 16px",
              fontWeight: 700,
              fontSize: 13,
              color: "#fff",
              background: ORANGE,
              cursor: "pointer",
            }}
          >
            <PrinterIcon size={14} /> Print Contract
          </button>
        </div>
      </div>

      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "2px solid #0f172a", paddingBottom: 16, marginBottom: 20 }}>
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 8, background: NAVY, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Building2 size={18} color="#fff" />
            </div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 15, color: "#0f172a" }}>DALTEX HQ</div>
              <div style={{ fontSize: 11.5, color: "#94a3b8" }}>IT ASSET MANAGEMENT DIVISION</div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a", letterSpacing: 0.4 }}>ASSET DELIVERY CONTRACT</div>
            <div style={{ fontSize: 11.5, color: "#94a3b8" }}>DOC_ID: {docId}</div>
            <div style={{ fontSize: 11.5, color: "#94a3b8" }}>DATE: {date}</div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 30, marginBottom: 24 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: ORANGE, letterSpacing: 0.4, marginBottom: 10 }}>RECIPIENT INFORMATION</div>
            {employee ? (
              <>
                <Row label="Employee Name" value={employee.name} />
                <Row label="Department" value={employee.dept} />
                <Row label="Employee ID" value={`EMP-${employee.id}`} />
                <Row label="Branch Location" value={employee.location} />
              </>
            ) : (
              <>
                <Row label="Branch Name" value={branchRecipient.branch.name} />
                <Row label="Department" value={branchRecipient.departmentName || "Whole Branch"} />
                <Row label="Branch ID" value={branchRecipient.branch.id} />
                <Row label="Region" value={branchRecipient.branch.region} />
              </>
            )}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: ORANGE, letterSpacing: 0.4, marginBottom: 10 }}>ISSUING OFFICER</div>
            <Row label="Officer Name" value={officer} />
            <Row label="IT Designation" value="Senior Asset Manager" />
            <Row label="Status" value={<StatusPill status="Assigned" />} />
          </div>
        </div>

        <div style={{ fontSize: 11, fontWeight: 700, color: "#475569", letterSpacing: 0.4, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
          <ClipboardCheck size={13} /> ASSIGNED IT ASSETS
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#f8fafc", textAlign: "left" }}>
              {["ASSET TYPE", "MAKE & MODEL", "SERIAL NUMBER", "CONDITION"].map((h) => (
                <th key={h} style={{ padding: "9px 14px", fontSize: 11, color: "#94a3b8", fontWeight: 700, borderBottom: "1px solid #eef0f3" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: "1px solid #f3f4f6" }}>
              <td style={{ padding: "12px 14px", fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{asset.category}</td>
              <td style={{ padding: "12px 14px", fontSize: 13, color: "#475569" }}>
                {asset.brand} {asset.model}
              </td>
              <td style={{ padding: "12px 14px", fontSize: 12.5, color: "#94a3b8" }}>SN: {asset.serial}</td>
              <td style={{ padding: "12px 14px" }}>
                <span style={{ background: "#dcfce7", color: "#15803d", fontSize: 11, fontWeight: 700, padding: "3px 9px", borderRadius: 999 }}>
                  {asset.condition.toUpperCase()}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ===== from pages/AssignmentsLog.jsx ===== */
function AssignmentsLog() {
  const { activity, assets, employees, setPage, returnAsset } = useApp();
  const assignedAssets = assets.filter((a) => a.status === "Assigned");

  function empName(id) {
    const e = employees.find((e) => e.id === id);
    return e ? e.name : "—";
  }

  return (
    <div style={{ padding: 28 }}>
      <BackButton onClick={() => setPage("dashboard")} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a" }}>Assignments</div>
          <div style={{ fontSize: 13, color: "#94a3b8", marginTop: 2 }}>Track active checkouts and recent assignment activity.</div>
        </div>
        <button
          onClick={() => setPage("newAssignment")}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 7,
            border: "none",
            borderRadius: 8,
            padding: "10px 18px",
            fontWeight: 700,
            fontSize: 13,
            color: "#fff",
            background: ORANGE,
            cursor: "pointer",
          }}
        >
          <Plus size={14} /> New Assignment
        </button>
      </div>

      <div style={{ display: "flex", gap: 20 }}>
        <Card style={{ flex: 3, padding: 0 }}>
          <div style={{ padding: "18px 20px", fontWeight: 800, fontSize: 15, color: "#0f172a" }}>Active Checkouts</div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ textAlign: "left" }}>
                {["ASSET", "ASSIGNED TO", "BRANCH", "CONDITION", ""].map((h) => (
                  <th key={h} style={{ padding: "8px 20px", fontSize: 11, color: "#94a3b8", fontWeight: 700, borderBottom: "1px solid #eef0f3" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {assignedAssets.map((a) => (
                <tr key={a.id} style={{ borderBottom: "1px solid #f3f4f6" }}>
                  <td style={{ padding: "13px 20px", display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 30, height: 30, borderRadius: 7, background: "#f1f5f9", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <CategoryIcon category={a.category} size={14} />
                    </div>
                    <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>
                      {a.brand} {a.model}
                    </span>
                  </td>
                  <td style={{ padding: "13px 20px", fontSize: 13, color: "#475569" }}>{empName(a.assignedTo)}</td>
                  <td style={{ padding: "13px 20px", fontSize: 13, color: "#475569" }}>{a.branch}</td>
                  <td style={{ padding: "13px 20px", fontSize: 12.5, color: "#94a3b8" }}>{a.condition}</td>
                  <td style={{ padding: "13px 20px" }}>
                    <button
                      onClick={() => returnAsset(a.id)}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                        border: "1px solid #eef0f3",
                        background: "#fff",
                        color: "#475569",
                        fontWeight: 700,
                        fontSize: 12,
                        padding: "6px 12px",
                        borderRadius: 7,
                        cursor: "pointer",
                      }}
                    >
                      <RotateCcw size={12} /> Return
                    </button>
                  </td>
                </tr>
              ))}
              {assignedAssets.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ padding: 30, textAlign: "center", color: "#94a3b8", fontSize: 13 }}>
                    No active checkouts.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </Card>

        <Card style={{ flex: 2 }}>
          <div style={{ fontWeight: 800, fontSize: 15, color: "#0f172a", marginBottom: 14 }}>Activity Log</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {activity.map((a) => (
              <div key={a.id} style={{ display: "flex", gap: 12 }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    flexShrink: 0,
                    background:
                      a.type === "assign" ? "#fef3e2" : a.type === "return" ? "#dcfce7" : a.type === "repair" ? "#fee2e2" : "#e2e8f0",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {a.type === "assign" && <Laptop size={15} color={ORANGE} />}
                  {a.type === "return" && <RotateCcw size={15} color="#16a34a" />}
                  {a.type === "repair" && <Wrench size={15} color="#dc2626" />}
                  {a.type === "audit" && <ClipboardCheck size={15} color="#475569" />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ fontWeight: 700, fontSize: 13, color: "#0f172a" }}>{a.title}</span>
                    <span style={{ fontSize: 11, color: "#94a3b8", flexShrink: 0, marginLeft: 8 }}>{a.time}</span>
                  </div>
                  <div style={{ fontSize: 12.5, color: "#64748b", marginTop: 1 }}>{a.desc}</div>
                  <div style={{ fontSize: 11.5, color: a.type === "return" ? "#16a34a" : "#94a3b8", marginTop: 1 }}>{a.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ===== from App.jsx ===== */
const NAV_ITEMS = [
  { key: "dashboard", label: "Dashboard", icon: <LayoutGrid size={17} /> },
  { key: "inventory", label: "Inventory", icon: <Boxes size={17} /> },
  { key: "employees", label: "Employees", icon: <Users size={17} /> },
  { key: "branches", label: "Branches", icon: <Building2 size={17} /> },
  { key: "assignments", label: "Assignments", icon: <ClipboardCheck size={17} /> },
];

const SEARCH_PLACEHOLDERS = {
  dashboard: "Search assets, serials, or users...",
  inventory: "Search inventory serials, assets, or users...",
  employees: "Search employees, assets, or serial numbers...",
  employeeDetail: "Search employees, assets, or serial numbers...",
  branches: "Search branches or departments...",
  branchDetail: "Search branches or departments...",
  assignments: "Search assets, serials, or users...",
  newAssignment: "Search assets, serials, or users...",
  contract: "Search assets, serials, or users...",
};

function Shell() {
  const {
    page,
    setPage,
    currentUser,
    logout,
    setInventoryStatusFilter,
    globalSearchQuery,
    setGlobalSearchQuery,
    showAddDeviceModal,
    setShowAddDeviceModal,
    addAsset,
  } = useApp();

  function navigate(key) {
    if (key === "inventory") setInventoryStatusFilter(null);
    setPage(key);
  }

  function handleAddNewAsset() {
    setShowAddDeviceModal(true);
  }

  function handleGlobalSearchChange(value) {
    setGlobalSearchQuery(value);
    // Typing in the global search box is most useful against the Inventory table,
    // so jump there as soon as the person starts typing (unless already there).
    if (value !== "" && page !== "inventory") {
      setInventoryStatusFilter(null);
      setPage("inventory");
    }
  }

  function handleGlobalSearchFocus() {
    if (page !== "inventory") {
      setInventoryStatusFilter(null);
      setPage("inventory");
    }
  }

  function handleAddDeviceSubmit(form) {
    addAsset(form);
    setShowAddDeviceModal(false);
  }

  const placeholder = SEARCH_PLACEHOLDERS[page] || SEARCH_PLACEHOLDERS.dashboard;
  const activeNav = ["newAssignment", "contract"].includes(page)
    ? "assignments"
    : page === "employeeDetail"
    ? "employees"
    : page === "branchDetail"
    ? "branches"
    : page;

  return (
    <div style={{ display: "flex", height: "100vh", background: "#f4f5f7", fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif" }}>
      <Sidebar items={NAV_ITEMS} activePage={activeNav} onNavigate={navigate} onAddNewAsset={handleAddNewAsset} brand="DALTEX HQ" sub="IT Asset Management" />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <TopBar
          placeholder={placeholder}
          userName={currentUser?.name || "Alex Mercer"}
          userRole={currentUser?.role || "Systems Admin"}
          avatarColor={currentUser?.avatar || "#475569"}
          alert={page === "dashboard"}
          onLogout={logout}
          searchValue={globalSearchQuery}
          onSearchChange={handleGlobalSearchChange}
          onSearchFocus={handleGlobalSearchFocus}
        />
        <div style={{ flex: 1, overflowY: "auto" }}>
          {page === "dashboard" && <Dashboard />}
          {page === "inventory" && <Inventory />}
          {page === "employees" && <EmployeeDirectory />}
          {page === "employeeDetail" && <EmployeeDetail />}
          {page === "branches" && <Branches />}
          {page === "branchDetail" && <BranchDetail />}
          {page === "assignments" && <AssignmentsLog />}
          {page === "newAssignment" && <NewAssignment />}
          {page === "contract" && <ContractPreview />}
        </div>
      </div>
      {showAddDeviceModal && <AddDeviceModal onClose={() => setShowAddDeviceModal(false)} onSubmit={handleAddDeviceSubmit} />}
    </div>
  );
}

function Root() {
  const { isAuthenticated } = useApp();
  return isAuthenticated ? <Shell /> : <Login />;
}

function App() {
  return (
    <AppProvider>
      <Root />
    </AppProvider>
  );
}

export default App;
